package com.example.ui.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.TelegramDarkHeader
import com.example.ui.theme.TelegramOnlineGreen

@Composable
fun TelegramChatTopBar(
    isTyping: Boolean,
    isCloudConnected: Boolean,
    onOpenTasks: () -> Unit,
    onOpenDebts: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenBrowser: () -> Unit = onOpenSettings,
    onClearChat: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(TelegramDarkHeader)
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("telegram_top_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Ram Avatar with online indicator
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "R",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                // Small online dot
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(TelegramOnlineGreen)
                        .align(Alignment.BottomEnd)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Title & Status
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenSettings() }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.chat_title),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    // Cloud Status Icon (subtle, no brand name)
                    Icon(
                        imageVector = if (isCloudConnected) Icons.Default.CloudDone else Icons.Default.CloudQueue,
                        contentDescription = "حالة الاتصال السحابي",
                        tint = if (isCloudConnected) TelegramOnlineGreen else Color.White.copy(alpha = 0.5f),
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { onOpenBrowser() }
                    )
                }

                AnimatedVisibility(visible = isTyping) {
                    Text(
                        text = stringResource(R.string.status_typing),
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                if (!isTyping) {
                    Text(
                        text = stringResource(R.string.status_online),
                        color = Color(0xFFA0B0C0),
                        fontSize = 13.sp
                    )
                }
            }

            // Quick access to features
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.testTag("top_bar_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "خيارات",
                        tint = Color.White
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("قائمة المهام") },
                        onClick = {
                            showMenu = false
                            onOpenTasks()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("دفتر الديون") },
                        onClick = {
                            showMenu = false
                            onOpenDebts()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("ذاكرة رام") },
                        onClick = {
                            showMenu = false
                            onOpenMemory()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("متصفح ديب سيك المباشر") },
                        onClick = {
                            showMenu = false
                            onOpenBrowser()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("الإعدادات وربط السحابة") },
                        onClick = {
                            showMenu = false
                            onOpenSettings()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("مسح المحادثة") },
                        onClick = {
                            showMenu = false
                            onClearChat()
                        }
                    )
                }
            }
        }
    }
}
