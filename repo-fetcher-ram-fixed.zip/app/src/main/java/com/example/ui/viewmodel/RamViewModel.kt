package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.RamDatabase
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatSessionEntity
import com.example.data.model.DebtEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.TaskEntity
import com.example.data.repository.RamRepository
import com.example.data.repository.UserPreferencesRepository
import com.example.domain.engine.DeepSeekBridge
import com.example.domain.engine.DeepSeekWebBridge
import com.example.domain.engine.RamEngine
import com.example.domain.engine.WebBridgeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RamViewModel(application: Application) : AndroidViewModel(application) {

    private val database = RamDatabase.getInstance(application)
    private val repository = RamRepository(database)
    val preferences = UserPreferencesRepository(application)
    val webBridge = DeepSeekWebBridge(application, preferences)
    private val bridge = DeepSeekBridge(application, preferences, webBridge)
    private val engine = RamEngine(repository, preferences, bridge)

    init {
        webBridge.onExternalUserPromptHandler = { userText ->
            val currentTasks = repository.getAllTasks()
            val currentDebts = repository.getAllDebts()
            val currentMemories = repository.getAllMemories()
            val userName = preferences.userName.value
            val userGender = preferences.userGender.value
            val recentMessages = repository.getRecentMessages(6)
            val historyPairs = recentMessages.map {
                (if (it.sender == com.example.data.model.MessageSender.USER) "USER" else "RAM") to it.text
            }
            val systemPrompt = com.example.domain.engine.RamPromptBuilder.buildSystemPrompt(userName, userGender)
            val contextBlocks = com.example.domain.engine.RamPromptBuilder.buildContextBlocks(
                now = java.util.Date(),
                tasks = currentTasks,
                debts = currentDebts,
                memories = currentMemories,
                plans = emptyList(),
                userMessage = userText,
                replyToText = null,
                conversationsCount = recentMessages.size,
                relationshipStage = preferences.sarcasmTolerance.value
            )
            bridge.sendPrompt(systemPrompt, contextBlocks, historyPairs)
        }
    }

    val chatMessages: StateFlow<List<ChatMessageEntity>> =
        repository.chatMessagesFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    val sessions: StateFlow<List<ChatSessionEntity>> =
        repository.sessionsFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    val tasks: StateFlow<List<TaskEntity>> =
        repository.tasksFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    val debts: StateFlow<List<DebtEntity>> =
        repository.debtsFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    val memories: StateFlow<List<MemoryEntity>> =
        repository.memoriesFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    val isRamTyping: StateFlow<Boolean> = engine.isRamTyping
    val webBridgeState: StateFlow<WebBridgeState> = webBridge.bridgeState
    val webBridgeLog: StateFlow<String> = webBridge.lastLog

    private val _selectedReplyMessage = MutableStateFlow<ChatMessageEntity?>(null)
    val selectedReplyMessage: StateFlow<ChatMessageEntity?> = _selectedReplyMessage.asStateFlow()

    private val _isTestingSession = MutableStateFlow(false)
    val isTestingSession: StateFlow<Boolean> = _isTestingSession.asStateFlow()

    private val _isWebOverlayVisible = MutableStateFlow(false)
    val isWebOverlayVisible: StateFlow<Boolean> = _isWebOverlayVisible.asStateFlow()

    fun showWebBrowser() {
        _isWebOverlayVisible.value = true
    }

    fun hideWebBrowser() {
        _isWebOverlayVisible.value = false
    }

    fun manualConfirmSession() {
        webBridge.manualConfirmLogin()
    }

    fun setReplyTo(message: ChatMessageEntity) {
        _selectedReplyMessage.value = message
    }

    fun clearReply() {
        _selectedReplyMessage.value = null
    }

    fun sendMessage(text: String) {
        val reply = _selectedReplyMessage.value
        _selectedReplyMessage.value = null

        viewModelScope.launch {
            engine.sendMessage(text, reply)
        }
    }

    fun confirmAction(actionJson: String) {
        viewModelScope.launch {
            engine.confirmAction(actionJson)
        }
    }

    /**
     * Start a new chat session and send the Ram v4.0 Persona document
     */
    fun createAndInitializeNewSession() {
        viewModelScope.launch {
            _isTestingSession.value = true
            val sessionId = repository.createNewSession("جلسة رام v4.0 (${System.currentTimeMillis() % 1000})")
            val activeSession = repository.getActiveSession()

            val success = webBridge.initializeRamPersonaSession()
            if (activeSession != null) {
                repository.updateSession(
                    activeSession.copy(
                        isRamPersonaInjected = true,
                        isFormatVerified = success,
                        lastTestResult = if (success) "تمت المصادقة واختبار JSON بنجاح" else "فشل التحقق من التنسيق"
                    )
                )
            }
            _isTestingSession.value = false
        }
    }

    /**
     * Test current session handshake & format compliance
     */
    fun testCurrentSession() {
        viewModelScope.launch {
            _isTestingSession.value = true
            val success = webBridge.initializeRamPersonaSession()
            val activeSession = repository.getActiveSession()
            if (activeSession != null) {
                repository.updateSession(
                    activeSession.copy(
                        isFormatVerified = success,
                        lastTestResult = if (success) "تم فحص التنسيق بنجاح وفق بروتوكول P5" else "فشل الفحص: الرد لم يلتزم بالـ JSON"
                    )
                )
            }
            _isTestingSession.value = false
        }
    }

    fun toggleTaskStatus(task: TaskEntity) {
        viewModelScope.launch {
            val newStatus = if (task.status == "منجزة") "لم تبدأ" else "منجزة"
            repository.updateTask(task.copy(status = newStatus))
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun addTask(title: String, due: String, priority: String, duration: String) {
        viewModelScope.launch {
            repository.insertTask(
                TaskEntity(
                    taskCode = "t${System.currentTimeMillis() % 1000}",
                    title = title,
                    due = due,
                    priority = priority,
                    estimatedDuration = duration,
                    status = "لم تبدأ"
                )
            )
        }
    }

    fun addDebt(party: String, direction: String, amount: Double, currency: String, due: String, notes: String) {
        viewModelScope.launch {
            repository.insertDebt(
                DebtEntity(
                    debtCode = "d${System.currentTimeMillis() % 1000}",
                    party = party,
                    direction = direction,
                    amount = amount,
                    currency = currency,
                    dueDate = due,
                    notes = notes,
                    debtDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH).format(java.util.Date())
                )
            )
        }
    }

    fun settleDebt(debt: DebtEntity, paidAmount: Double) {
        viewModelScope.launch {
            val updated = debt.copy(paidAmount = (debt.paidAmount + paidAmount).coerceAtMost(debt.amount))
            repository.updateDebt(updated)
        }
    }

    fun deleteDebt(debt: DebtEntity) {
        viewModelScope.launch {
            repository.deleteDebt(debt)
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }

    fun onCloudSessionLoggedIn(cookies: String, token: String = "") {
        preferences.setCloudSession(cookies, token)
    }

    fun disconnectCloud() {
        preferences.clearCloudSession()
    }
}
