package com.example.ui.debts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DebtEntity
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TelegramDarkHeader
import com.example.ui.theme.TelegramReplyAccent
import com.example.ui.viewmodel.RamViewModel

@Composable
fun DebtsScreen(
    viewModel: RamViewModel,
    onBack: () -> Unit
) {
    val debts by viewModel.debts.collectAsState()
    var selectedTabIndex by remember { mutableStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    var debtToSettle by remember { mutableStateOf<DebtEntity?>(null) }

    val totalOwedToMe = remember(debts) {
        debts.filter { it.direction == "لي" }.sumOf { it.remainingAmount }
    }
    val totalIOwe = remember(debts) {
        debts.filter { it.direction == "عليّ" }.sumOf { it.remainingAmount }
    }

    val filteredDebts = remember(debts, selectedTabIndex) {
        when (selectedTabIndex) {
            1 -> debts.filter { it.direction == "لي" }
            2 -> debts.filter { it.direction == "عليّ" }
            else -> debts
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TelegramDarkHeader)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("debts_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع للمحادثة",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "دفتر الديون",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "المسجل في الدفتر لا يضيع",
                        color = Color(0xFFA0B0C0),
                        fontSize = 12.sp
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = TelegramReplyAccent,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("add_debt_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "تسجيل دين جديد")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Summary Cards
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.12f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ديون لي (مستحقة)", fontSize = 12.sp, color = SuccessGreen)
                        Text("$totalOwedToMe $", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = SuccessGreen)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.12f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ديون عليّ (التزامات)", fontSize = 12.sp, color = DangerRed)
                        Text("$totalIOwe $", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = DangerRed)
                    }
                }
            }

            TabRow(selectedTabIndex = selectedTabIndex) {
                listOf("الكل", "ديون لي", "ديون عليّ").forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title) }
                    )
                }
            }

            if (filteredDebts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "دفتر الديون فارغ في هذا التصنيف. يمكنك أن تطلب من رام تسجيل أي دين أو سداد.",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                ) {
                    items(filteredDebts, key = { it.id }) { debt ->
                        DebtCardItem(
                            debt = debt,
                            onSettle = { debtToSettle = debt },
                            onDelete = { viewModel.deleteDebt(debt) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddDebtDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { party, direction, amount, currency, due, notes ->
                viewModel.addDebt(party, direction, amount, currency, due, notes)
                showAddDialog = false
            }
        )
    }

    debtToSettle?.let { debt ->
        SettleDebtDialog(
            debt = debt,
            onDismiss = { debtToSettle = null },
            onConfirm = { amount ->
                viewModel.settleDebt(debt, amount)
                debtToSettle = null
            }
        )
    }
}

@Composable
fun DebtCardItem(
    debt: DebtEntity,
    onSettle: () -> Unit,
    onDelete: () -> Unit
) {
    val isOwedToMe = debt.direction == "لي"
    val accentColor = if (isOwedToMe) SuccessGreen else DangerRed

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("debt_item_${debt.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(accentColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isOwedToMe) "لي على" else "عليّ لـ",
                            color = accentColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = debt.party,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Text(
                    text = "${debt.amount} ${debt.currency}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = accentColor
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "المسدد: ${debt.paidAmount} | المتبقي: ${debt.remainingAmount}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    if (debt.dueDate.isNotBlank()) {
                        Text(
                            text = "الاستحقاق: ${debt.dueDate}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Row {
                    if (!debt.isFullyPaid) {
                        Button(
                            onClick = onSettle,
                            colors = ButtonDefaults.buttonColors(containerColor = TelegramReplyAccent),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("تسديد", fontSize = 11.sp)
                        }
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف الدين",
                            tint = DangerRed.copy(alpha = 0.6f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddDebtDialog(
    onDismiss: () -> Unit,
    onConfirm: (party: String, direction: String, amount: Double, currency: String, due: String, notes: String) -> Unit
) {
    var party by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("لي") }
    var amountStr by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("USD") }
    var due by remember { mutableStateOf("نهاية الشهر") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل دين في الدفتر") },
        text = {
            Column {
                OutlinedTextField(
                    value = party,
                    onValueChange = { party = it },
                    label = { Text("الطرف (الشخص / المحل)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row {
                    Button(
                        onClick = { direction = "لي" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (direction == "لي") SuccessGreen else Color.Gray.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("دين لي")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { direction = "عليّ" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (direction == "عليّ") DangerRed else Color.Gray.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("دين عليّ")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("المبلغ") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = due,
                    onValueChange = { due = it },
                    label = { Text("تاريخ الاستحقاق") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull() ?: 0.0
                    if (party.isNotBlank() && amount > 0) {
                        onConfirm(party, direction, amount, currency, due, "")
                    }
                }
            ) {
                Text("تسجيل")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun SettleDebtDialog(
    debt: DebtEntity,
    onDismiss: () -> Unit,
    onConfirm: (amount: Double) -> Unit
) {
    var settleAmountStr by remember { mutableStateOf(debt.remainingAmount.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسديد دفعة للدين (${debt.party})") },
        text = {
            Column {
                Text("المتبقي حالياً: ${debt.remainingAmount} ${debt.currency}")
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = settleAmountStr,
                    onValueChange = { settleAmountStr = it },
                    label = { Text("المبلغ المدفوع") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = settleAmountStr.toDoubleOrNull() ?: 0.0
                    if (amt > 0) onConfirm(amt)
                }
            ) {
                Text("تأكيد التسديد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
