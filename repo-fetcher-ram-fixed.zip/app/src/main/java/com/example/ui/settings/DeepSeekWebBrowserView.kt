package com.example.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VerticalSplit
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.domain.engine.ConsoleLogLevel
import com.example.domain.engine.DeepSeekWebBridge
import com.example.domain.engine.WebConsoleEntry
import com.example.ui.theme.TelegramDarkHeader
import com.example.ui.theme.TelegramOnlineGreen
import com.example.ui.theme.TelegramReplyAccent

enum class ConsoleFilter {
    ALL,
    ERRORS,
    DOM_PROTECT,
    NETWORK,
    WARNINGS
}

enum class ConsoleDisplayMode {
    COLLAPSED,      // Only floating FAB pill visible
    SPLIT_VIEW,     // 50% WebView on top, 50% Live Console on bottom
    FULL_CONSOLE    // Full screen Console for extensive debugging
}

@Composable
fun DeepSeekWebBrowserView(
    webBridge: DeepSeekWebBridge,
    onClose: () -> Unit,
    onConfirmSession: () -> Unit
) {
    val context = LocalContext.current
    val currentUrl by webBridge.currentUrl.collectAsState()
    val pageTitle by webBridge.pageTitle.collectAsState()
    val hasInput by webBridge.hasInputField.collectAsState()
    val isLoading by webBridge.isLoading.collectAsState()
    val loadProgress by webBridge.loadProgress.collectAsState()
    val canGoBack by webBridge.canGoBack.collectAsState()
    val canGoForward by webBridge.canGoForward.collectAsState()
    val isDesktopMode by webBridge.isDesktopMode.collectAsState()
    val lastLog by webBridge.lastLog.collectAsState()
    val consoleLogs by webBridge.consoleLogs.collectAsState()

    var urlInputText by remember { mutableStateOf(currentUrl) }
    var showShortcutsDrawer by remember { mutableStateOf(false) }
    var consoleMode by remember { mutableStateOf(ConsoleDisplayMode.COLLAPSED) }
    var showAutofillPanel by remember { mutableStateOf(false) }
    var testEmail by remember { mutableStateOf("") }
    var testPassword by remember { mutableStateOf("") }
    var activeFilter by remember { mutableStateOf(ConsoleFilter.ALL) }
    var jsCommandInput by remember { mutableStateOf("") }

    val focusManager = LocalFocusManager.current

    val errorCount = remember(consoleLogs) {
        consoleLogs.count { it.level == ConsoleLogLevel.ERROR }
    }
    val domProtectCount = remember(consoleLogs) {
        consoleLogs.count { it.level == ConsoleLogLevel.DOM_PROTECT }
    }
    val networkCount = remember(consoleLogs) {
        consoleLogs.count { it.level == ConsoleLogLevel.NETWORK }
    }

    LaunchedEffect(currentUrl) {
        if (!urlInputText.equals(currentUrl, ignoreCase = true)) {
            urlInputText = currentUrl
        }
    }

    BackHandler {
        if (consoleMode != ConsoleDisplayMode.COLLAPSED) {
            consoleMode = ConsoleDisplayMode.COLLAPSED
        } else if (canGoBack) {
            webBridge.goBack()
        } else {
            onClose()
        }
    }

    val isDeepSeekReady = hasInput || (!currentUrl.contains("/sign_in") && !currentUrl.contains("/login") && currentUrl.contains("chat.deepseek.com"))

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("deepseek_browser_surface"),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            Column(modifier = Modifier.fillMaxSize()) {
                // ═══════════════════════════════════════════════════════════════
                // 1. Browser Navigation Header
                // ═══════════════════════════════════════════════════════════════
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TelegramDarkHeader)
                        .padding(horizontal = 4.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق المتصفح",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = { webBridge.goBack() },
                        enabled = canGoBack,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "السابق",
                            tint = if (canGoBack) Color.White else Color.Gray.copy(alpha = 0.5f)
                        )
                    }

                    IconButton(
                        onClick = { webBridge.goForward() },
                        enabled = canGoForward,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "التالي",
                            tint = if (canGoForward) Color.White else Color.Gray.copy(alpha = 0.5f)
                        )
                    }

                    IconButton(
                        onClick = { if (isLoading) webBridge.stopLoading() else webBridge.reload() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (isLoading) Icons.Default.Close else Icons.Default.Refresh,
                            contentDescription = if (isLoading) "إيقاف" else "تحديث",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(3.dp))

                    OutlinedTextField(
                        value = urlInputText,
                        onValueChange = { urlInputText = it },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = Color.White),
                        placeholder = {
                            Text(
                                "اكتب الرابط أو ابحث...",
                                fontSize = 10.sp,
                                color = Color(0xFFA0B0C0)
                            )
                        },
                        leadingIcon = {
                            val isHttps = currentUrl.startsWith("https://")
                            Icon(
                                imageVector = if (isHttps) Icons.Default.Lock else Icons.Default.Language,
                                contentDescription = null,
                                tint = if (isHttps) TelegramOnlineGreen else Color.LightGray,
                                modifier = Modifier.size(13.dp)
                            )
                        },
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (urlInputText.isNotBlank()) {
                                    IconButton(
                                        onClick = { urlInputText = "" },
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "مسح",
                                            tint = Color.LightGray,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        focusManager.clearFocus()
                                        webBridge.loadUrl(urlInputText)
                                    },
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "انتقال",
                                        tint = TelegramOnlineGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Go
                        ),
                        keyboardActions = KeyboardActions(
                            onGo = {
                                focusManager.clearFocus()
                                webBridge.loadUrl(urlInputText)
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TelegramReplyAccent,
                            unfocusedBorderColor = Color(0xFF384756),
                            focusedContainerColor = Color(0xFF1E2834),
                            unfocusedContainerColor = Color(0xFF1E2834),
                            cursorColor = TelegramOnlineGreen
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                    )

                    Spacer(modifier = Modifier.width(3.dp))

                    // Console Toggle Button in Header
                    Surface(
                        onClick = {
                            consoleMode = when (consoleMode) {
                                ConsoleDisplayMode.COLLAPSED -> ConsoleDisplayMode.SPLIT_VIEW
                                ConsoleDisplayMode.SPLIT_VIEW -> ConsoleDisplayMode.FULL_CONSOLE
                                ConsoleDisplayMode.FULL_CONSOLE -> ConsoleDisplayMode.COLLAPSED
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = when {
                            errorCount > 0 -> Color(0xFFD32F2F)
                            consoleMode != ConsoleDisplayMode.COLLAPSED -> TelegramReplyAccent
                            else -> Color(0xFF263238)
                        },
                        modifier = Modifier.height(30.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = "الكونسول",
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (errorCount > 0) "$errorCount خطأ" else "كونسول",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(3.dp))

                    // Shortcuts Toggle
                    IconButton(
                        onClick = { showShortcutsDrawer = !showShortcutsDrawer },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = if (showShortcutsDrawer) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "أدوات",
                            tint = if (showShortcutsDrawer) TelegramReplyAccent else Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(3.dp))

                    // Direct One-Tap Switcher between DeepSeek Live Web and Local React Client
                    val isLocalClient = currentUrl.startsWith("file://")
                    Surface(
                        onClick = {
                            if (isLocalClient) {
                                webBridge.loadChatPage()
                            } else {
                                webBridge.loadLocalReactClient()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isLocalClient) Color(0xFF1E3A5F) else Color(0xFF253342),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isLocalClient) "🌐 شات الويب" else "⚡ React",
                                color = if (isLocalClient) Color(0xFF67E8F9) else Color(0xFFB0BEC5),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(3.dp))

                    // Confirm / Sync Session Button
                    Button(
                        onClick = onConfirmSession,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDeepSeekReady) TelegramOnlineGreen else TelegramReplyAccent
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            if (isDeepSeekReady) "اعتماد" else "ربط",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (isLoading && loadProgress in 1..99) {
                    LinearProgressIndicator(
                        progress = { loadProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp),
                        color = TelegramOnlineGreen,
                        trackColor = Color(0xFF24303F)
                    )
                }

                // ═══════════════════════════════════════════════════════════════
                // Shortcuts Drawer
                // ═══════════════════════════════════════════════════════════════
                AnimatedVisibility(
                    visible = showShortcutsDrawer,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF19232F))
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            AssistChip(
                                onClick = {
                                    webBridge.loadLocalReactClient()
                                    showShortcutsDrawer = false
                                },
                                label = { Text("⚡ عميل React المدمج", fontSize = 11.sp, color = Color(0xFF67E8F9), fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF1E3A5F)),
                                border = null,
                                shape = RoundedCornerShape(12.dp)
                            )

                            AssistChip(
                                onClick = {
                                    webBridge.loadChatPage()
                                    showShortcutsDrawer = false
                                },
                                label = { Text("🌐 ديب سيك شات", fontSize = 11.sp, color = Color.White) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF283646)),
                                border = null,
                                shape = RoundedCornerShape(12.dp)
                            )

                            AssistChip(
                                onClick = {
                                    webBridge.loadSignInPage()
                                    showShortcutsDrawer = false
                                },
                                label = { Text("🔑 ديب سيك دخول", fontSize = 11.sp, color = Color.White) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF283646)),
                                border = null,
                                shape = RoundedCornerShape(12.dp)
                            )

                            AssistChip(
                                onClick = {
                                    webBridge.runLiveDomInspection()
                                    consoleMode = ConsoleDisplayMode.SPLIT_VIEW
                                    showShortcutsDrawer = false
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.FindInPage, contentDescription = null, tint = TelegramOnlineGreen, modifier = Modifier.size(13.dp))
                                },
                                label = { Text("فحص الـ DOM الآن", fontSize = 11.sp, color = Color.White) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF2E3D4D)),
                                border = null,
                                shape = RoundedCornerShape(12.dp)
                            )

                            AssistChip(
                                onClick = {
                                    webBridge.forceRestoreChatElements()
                                    Toast.makeText(context, "تم تطبيق أمر استعادة عناصر الشات", Toast.LENGTH_SHORT).show()
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = Color(0xFF67E8F9), modifier = Modifier.size(13.dp))
                                },
                                label = { Text("إظهار الشات بالقوة", fontSize = 11.sp, color = Color.White) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF2E3D4D)),
                                border = null,
                                shape = RoundedCornerShape(12.dp)
                            )

                            AssistChip(
                                onClick = { webBridge.toggleDesktopMode() },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isDesktopMode) Icons.Default.Computer else Icons.Default.PhoneAndroid,
                                        contentDescription = null,
                                        tint = if (isDesktopMode) TelegramOnlineGreen else Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        if (isDesktopMode) "وضع كمبيوتر" else "وضع جوال",
                                        fontSize = 11.sp,
                                        color = Color.White
                                    )
                                },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF243444)),
                                border = null,
                                shape = RoundedCornerShape(12.dp)
                            )

                            AssistChip(
                                onClick = { webBridge.clearCacheAndCookies() },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.DeleteSweep,
                                        contentDescription = null,
                                        tint = Color(0xFFFF8A80),
                                        modifier = Modifier.size(13.dp)
                                    )
                                },
                                label = { Text("مسح الكاش والكوكيز", fontSize = 11.sp, color = Color.White) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF332025)),
                                border = null,
                                shape = RoundedCornerShape(12.dp)
                            )

                            AssistChip(
                                onClick = { showAutofillPanel = !showAutofillPanel },
                                leadingIcon = {
                                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = TelegramOnlineGreen, modifier = Modifier.size(13.dp))
                                },
                                label = { Text("تعبئة تلقائية للحقول", fontSize = 11.sp, color = Color.White) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF243444)),
                                border = null,
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        if (showAutofillPanel) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF222C38)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().padding(4.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "تعبئة الحساب (اتجاه LTR لمنع عكس الحروف):",
                                            fontSize = 11.sp,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                        // Quick Button to reverse text if already typed backwards
                                        TextButton(
                                            onClick = {
                                                testEmail = testEmail.reversed()
                                                testPassword = testPassword.reversed()
                                                Toast.makeText(context, "تم عكس اتجاه النص وتصحيحه", Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Text("🔄 تصحيح النص المعكوس", fontSize = 10.sp, color = TelegramOnlineGreen)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        OutlinedTextField(
                                            value = testEmail,
                                            onValueChange = { testEmail = it },
                                            label = { Text("Email / Phone (LTR)", fontSize = 11.sp) },
                                            singleLine = true,
                                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                                textDirection = TextDirection.Ltr,
                                                textAlign = TextAlign.Start,
                                                color = Color.White
                                            ),
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Email,
                                                imeAction = ImeAction.Next,
                                                autoCorrect = false
                                            ),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = TelegramReplyAccent,
                                                unfocusedBorderColor = Color(0xFF384756),
                                                focusedContainerColor = Color(0xFF161E28),
                                                unfocusedContainerColor = Color(0xFF161E28)
                                            ),
                                            modifier = Modifier.fillMaxWidth().height(48.dp)
                                        )

                                        Spacer(modifier = Modifier.height(6.dp))

                                        OutlinedTextField(
                                            value = testPassword,
                                            onValueChange = { testPassword = it },
                                            label = { Text("Password (LTR)", fontSize = 11.sp) },
                                            singleLine = true,
                                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                                textDirection = TextDirection.Ltr,
                                                textAlign = TextAlign.Start,
                                                color = Color.White
                                            ),
                                            visualTransformation = PasswordVisualTransformation(),
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Password,
                                                imeAction = ImeAction.Done,
                                                autoCorrect = false
                                            ),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = TelegramReplyAccent,
                                                unfocusedBorderColor = Color(0xFF384756),
                                                focusedContainerColor = Color(0xFF161E28),
                                                unfocusedContainerColor = Color(0xFF161E28)
                                            ),
                                            modifier = Modifier.fillMaxWidth().height(48.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(onClick = { showAutofillPanel = false }) {
                                            Text("إلغاء", fontSize = 11.sp)
                                        }

                                        Spacer(modifier = Modifier.width(4.dp))

                                        Button(
                                            onClick = {
                                                webBridge.autofillCredentials(testEmail.trim(), testPassword.trim(), autoSubmit = false)
                                                showAutofillPanel = false
                                                Toast.makeText(context, "تم حقن البيانات بالاتجاه السليم", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF26384C))
                                        ) {
                                            Text("حقن فقط", fontSize = 11.sp)
                                        }

                                        Spacer(modifier = Modifier.width(4.dp))

                                        Button(
                                            onClick = {
                                                webBridge.autofillCredentials(testEmail.trim(), testPassword.trim(), autoSubmit = true)
                                                showAutofillPanel = false
                                                Toast.makeText(context, "جاري الحقن وتسجيل الدخول تلقائياً...", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = TelegramOnlineGreen)
                                        ) {
                                            Text("حقن ودخول 🚀", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Compact Status & Info Ticker
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF141A21))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (isDeepSeekReady) TelegramOnlineGreen else Color(0xFFFFB300))
                            .size(7.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isDeepSeekReady) "ديب سيك جاهز ومسجل الدخول" else "بانتظار تسجيل الدخول...",
                        fontSize = 10.sp,
                        color = if (isDeepSeekReady) TelegramOnlineGreen else Color(0xFFFFB300),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• $lastLog",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.LightGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }

                // ═══════════════════════════════════════════════════════════════
                // Main Content Area: Persistent Single AndroidView & DevTools
                // ═══════════════════════════════════════════════════════════════
                val webViewWeight = when (consoleMode) {
                    ConsoleDisplayMode.COLLAPSED -> 1f
                    ConsoleDisplayMode.SPLIT_VIEW -> 0.48f
                    ConsoleDisplayMode.FULL_CONSOLE -> 0.001f
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(webViewWeight)
                        .background(Color(0xFF141A21))
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            val wv = webBridge.createOrGetWebView(ctx)
                            (wv.parent as? ViewGroup)?.removeView(wv)
                            wv
                        },
                        update = { wv ->
                            wv.requestLayout()
                            wv.invalidate()
                        }
                    )
                }

                if (consoleMode != ConsoleDisplayMode.COLLAPSED) {
                    HorizontalDivider(color = TelegramReplyAccent, thickness = 2.dp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(if (consoleMode == ConsoleDisplayMode.SPLIT_VIEW) 0.52f else 0.999f)
                    ) {
                        LiveConsolePanel(
                            webBridge = webBridge,
                            consoleLogs = consoleLogs,
                            errorCount = errorCount,
                            domProtectCount = domProtectCount,
                            networkCount = networkCount,
                            activeFilter = activeFilter,
                            onFilterChange = { activeFilter = it },
                            jsCommandInput = jsCommandInput,
                            onJsCommandChange = { jsCommandInput = it },
                            consoleMode = consoleMode,
                            onModeChange = { consoleMode = it }
                        )
                    }
                }
            }

            // ═══════════════════════════════════════════════════════════════
            // Floating DevTools Pill Button (Always accessible when collapsed)
            // ═══════════════════════════════════════════════════════════════
            if (consoleMode == ConsoleDisplayMode.COLLAPSED) {
                Surface(
                    onClick = { consoleMode = ConsoleDisplayMode.SPLIT_VIEW },
                    shape = RoundedCornerShape(24.dp),
                    color = if (errorCount > 0) Color(0xFFD32F2F) else Color(0xFF1E2834),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 16.dp, end = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (errorCount > 0) Icons.Default.BugReport else Icons.Default.Terminal,
                            contentDescription = "فتح الكونسول",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (errorCount > 0) "$errorCount أخطاء | فتح الكونسول" else "💻 فتح الكونسول المباشر",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LiveConsolePanel(
    webBridge: DeepSeekWebBridge,
    consoleLogs: List<WebConsoleEntry>,
    errorCount: Int,
    domProtectCount: Int,
    networkCount: Int,
    activeFilter: ConsoleFilter,
    onFilterChange: (ConsoleFilter) -> Unit,
    jsCommandInput: String,
    onJsCommandChange: (String) -> Unit,
    consoleMode: ConsoleDisplayMode,
    onModeChange: (ConsoleDisplayMode) -> Unit
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1017))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = TelegramOnlineGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "كونسول فحص أخطاء الشات (DevTools)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "(${consoleLogs.size})",
                        fontSize = 10.sp,
                        color = Color.LightGray
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Inspect DOM Button
                    IconButton(
                        onClick = { webBridge.runLiveDomInspection() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.FindInPage, contentDescription = "فحص الـ DOM", tint = TelegramOnlineGreen, modifier = Modifier.size(16.dp))
                    }

                    // Force Restore Chat Button
                    IconButton(
                        onClick = {
                            webBridge.forceRestoreChatElements()
                            Toast.makeText(context, "تم إزالة طبقات الخطأ واستعادة عناصر الشات", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = "استعادة الشات", tint = Color(0xFF67E8F9), modifier = Modifier.size(16.dp))
                    }

                    // Copy All Logs
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val text = consoleLogs.joinToString("\n") {
                                "[${it.timestamp}] [${it.level}] ${it.source}:${it.lineNumber} -> ${it.message}"
                            }
                            clipboard.setPrimaryClip(ClipData.newPlainText("DeepSeek Console Logs", text))
                            Toast.makeText(context, "تم نسخ جميع السجلات للأخطاء (${consoleLogs.size}) للحافظة!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "نسخ التقرير", tint = Color.LightGray, modifier = Modifier.size(15.dp))
                    }

                    // Clear Logs
                    IconButton(
                        onClick = { webBridge.clearConsoleLogs() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "مسح السجل", tint = Color.LightGray, modifier = Modifier.size(15.dp))
                    }

                    // Toggle Split vs Full
                    IconButton(
                        onClick = {
                            onModeChange(if (consoleMode == ConsoleDisplayMode.FULL_CONSOLE) ConsoleDisplayMode.SPLIT_VIEW else ConsoleDisplayMode.FULL_CONSOLE)
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (consoleMode == ConsoleDisplayMode.FULL_CONSOLE) Icons.Default.VerticalSplit else Icons.Default.Fullscreen,
                            contentDescription = "تبديل الشاشة",
                            tint = Color.LightGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Close / Collapse
                    IconButton(
                        onClick = { onModeChange(ConsoleDisplayMode.COLLAPSED) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "تصغير", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Diagnostic Info Banner when errors exist
            if (errorCount > 0 || domProtectCount > 0) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (errorCount > 0) Color(0x33FF5252) else Color(0x337C4DFF),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (errorCount > 0) Icons.Default.BugReport else Icons.Default.Security,
                            contentDescription = null,
                            tint = if (errorCount > 0) Color(0xFFFF8A80) else Color(0xFFB388FF),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (errorCount > 0)
                                "⚠️ رُصدت أخطاء في الصفحة! دالة _sriCk أو حظر الـ CORS/WAF قد يحاول إخفاء الـ DOM. تم تفعيل الحماية لمنع حذف الشات."
                            else
                                "🛡️ دروع حماية الـ DOM نشطة وتمنع دالة _sriCk من تفريغ عناصر الصفحة.",
                            fontSize = 9.sp,
                            color = Color.White,
                            lineHeight = 12.sp
                        )
                    }
                }
            }

            // Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                FilterChip(
                    selected = activeFilter == ConsoleFilter.ALL,
                    onClick = { onFilterChange(ConsoleFilter.ALL) },
                    label = { Text("الكل (${consoleLogs.size})", fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF263238), selectedLabelColor = Color.White)
                )
                FilterChip(
                    selected = activeFilter == ConsoleFilter.ERRORS,
                    onClick = { onFilterChange(ConsoleFilter.ERRORS) },
                    label = { Text("🔴 أخطاء ($errorCount)", fontSize = 10.sp, color = if (errorCount > 0) Color(0xFFFF5252) else Color.LightGray) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF5A1A1A), selectedLabelColor = Color(0xFFFF8A80))
                )
                FilterChip(
                    selected = activeFilter == ConsoleFilter.DOM_PROTECT,
                    onClick = { onFilterChange(ConsoleFilter.DOM_PROTECT) },
                    label = { Text("🛡️ حماية الـ DOM ($domProtectCount)", fontSize = 10.sp, color = Color(0xFFB388FF)) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF321A5A), selectedLabelColor = Color(0xFFE1BEE7))
                )
                FilterChip(
                    selected = activeFilter == ConsoleFilter.NETWORK,
                    onClick = { onFilterChange(ConsoleFilter.NETWORK) },
                    label = { Text("🌐 شبكة ($networkCount)", fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF1A3A3A), selectedLabelColor = Color(0xFF80CBC4))
                )
                FilterChip(
                    selected = activeFilter == ConsoleFilter.WARNINGS,
                    onClick = { onFilterChange(ConsoleFilter.WARNINGS) },
                    label = { Text("تحذيرات", fontSize = 10.sp) }
                )
            }

            HorizontalDivider(color = Color(0xFF1E2834), thickness = 1.dp)

            // Logs List
            val filteredLogs = remember(consoleLogs, activeFilter) {
                when (activeFilter) {
                    ConsoleFilter.ALL -> consoleLogs
                    ConsoleFilter.ERRORS -> consoleLogs.filter { it.level == ConsoleLogLevel.ERROR }
                    ConsoleFilter.DOM_PROTECT -> consoleLogs.filter { it.level == ConsoleLogLevel.DOM_PROTECT }
                    ConsoleFilter.NETWORK -> consoleLogs.filter { it.level == ConsoleLogLevel.NETWORK }
                    ConsoleFilter.WARNINGS -> consoleLogs.filter { it.level == ConsoleLogLevel.WARNING }
                }
            }

            val listState = rememberLazyListState()
            LaunchedEffect(filteredLogs.size) {
                if (filteredLogs.isNotEmpty()) {
                    listState.scrollToItem(filteredLogs.size - 1)
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFF06090D))
                    .padding(2.dp)
            ) {
                if (filteredLogs.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("لا توجد سجلات في هذا التصنيف حالياً", color = Color.Gray, fontSize = 10.sp)
                        }
                    }
                } else {
                    items(filteredLogs, key = { it.id }) { log ->
                        ConsoleLogRow(log)
                    }
                }
            }

            // Quick JS Snippets Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AssistChip(
                    onClick = { webBridge.evaluateUserJs("document.getElementById('root') ? 'Root exists, children: ' + document.getElementById('root').children.length : 'Root NOT found'") },
                    label = { Text("فحص #root", fontSize = 9.sp) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF16202C)),
                    border = null,
                    modifier = Modifier.height(24.dp)
                )
                AssistChip(
                    onClick = { webBridge.evaluateUserJs("document.querySelector('div._sri-ck') ? 'SRI error screen is present!' : 'No SRI error'") },
                    label = { Text("فحص _sri-ck", fontSize = 9.sp) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF16202C)),
                    border = null,
                    modifier = Modifier.height(24.dp)
                )
                AssistChip(
                    onClick = { webBridge.evaluateUserJs("localStorage.getItem('userToken') ? 'Token found: ' + localStorage.getItem('userToken').substring(0, 30) : 'No userToken in localStorage'") },
                    label = { Text("فحص التوكن", fontSize = 9.sp) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF16202C)),
                    border = null,
                    modifier = Modifier.height(24.dp)
                )
                AssistChip(
                    onClick = { webBridge.evaluateUserJs("document.querySelectorAll('textarea, input').length + ' inputs found'") },
                    label = { Text("فحص الحقول", fontSize = 9.sp) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF16202C)),
                    border = null,
                    modifier = Modifier.height(24.dp)
                )
                AssistChip(
                    onClick = { webBridge.evaluateUserJs("document.body.innerHTML.substring(0, 300)") },
                    label = { Text("عرض بداية الـ Body", fontSize = 9.sp) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF16202C)),
                    border = null,
                    modifier = Modifier.height(24.dp)
                )
            }

            // Interactive JS REPL runner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF111720))
                    .padding(3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("JS >", color = TelegramOnlineGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.width(4.dp))
                OutlinedTextField(
                    value = jsCommandInput,
                    onValueChange = onJsCommandChange,
                    placeholder = { Text("اكتب أمر JS (مثال: location.href أو document.title)", fontSize = 10.sp, color = Color.Gray) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (jsCommandInput.isNotBlank()) {
                                webBridge.evaluateUserJs(jsCommandInput.trim())
                                onJsCommandChange("")
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TelegramReplyAccent,
                        unfocusedBorderColor = Color(0xFF263238),
                        focusedContainerColor = Color(0xFF070B0E),
                        unfocusedContainerColor = Color(0xFF070B0E)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                IconButton(
                    onClick = {
                        if (jsCommandInput.isNotBlank()) {
                            webBridge.evaluateUserJs(jsCommandInput.trim())
                            onJsCommandChange("")
                        }
                    },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "تنفيذ", tint = TelegramOnlineGreen, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun ConsoleLogRow(log: WebConsoleEntry) {
    val levelColor = when (log.level) {
        ConsoleLogLevel.ERROR -> Color(0xFFFF5252)
        ConsoleLogLevel.DOM_PROTECT -> Color(0xFFB388FF)
        ConsoleLogLevel.WARNING -> Color(0xFFFFD740)
        ConsoleLogLevel.INFO -> Color(0xFF40C4FF)
        ConsoleLogLevel.DEBUG -> Color(0xFFE0E0E0)
        ConsoleLogLevel.NETWORK -> Color(0xFF69F0AE)
        ConsoleLogLevel.JS_EVAL -> Color(0xFFFFAB40)
        ConsoleLogLevel.LOG -> Color(0xFFB0BEC5)
    }

    val levelBg = when (log.level) {
        ConsoleLogLevel.ERROR -> Color(0x33FF5252)
        ConsoleLogLevel.DOM_PROTECT -> Color(0x28B388FF)
        ConsoleLogLevel.WARNING -> Color(0x28FFD740)
        ConsoleLogLevel.NETWORK -> Color(0x2269F0AE)
        else -> Color.Transparent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(levelBg)
            .padding(horizontal = 4.dp, vertical = 2.5.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = log.timestamp,
            fontSize = 8.5.sp,
            fontFamily = FontFamily.Monospace,
            color = Color.Gray,
            modifier = Modifier.width(60.dp)
        )

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(levelColor.copy(alpha = 0.2f))
                .padding(horizontal = 3.dp, vertical = 1.dp)
        ) {
            Text(
                text = when (log.level) {
                    ConsoleLogLevel.DOM_PROTECT -> "GUARD"
                    ConsoleLogLevel.JS_EVAL -> "EVAL"
                    else -> log.level.name.take(4)
                },
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = levelColor
            )
        }

        Spacer(modifier = Modifier.width(5.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = log.message,
                fontSize = 9.5.sp,
                fontFamily = FontFamily.Monospace,
                color = if (log.level == ConsoleLogLevel.ERROR) Color(0xFFFF8A80) else Color(0xFFE0E0E0)
            )

            if (log.source.isNotBlank()) {
                Text(
                    text = "${log.source}:${log.lineNumber}",
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.DarkGray
                )
            }
        }
    }
}
