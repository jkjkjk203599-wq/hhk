package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Telegram theme colors
val TelegramDarkBg = Color(0xFF0E1621)
val TelegramLightBg = Color(0xFFEFEFEF)
val TelegramDarkHeader = Color(0xFF17212B)
val TelegramDateChipBg = Color(0x73000000)
val TelegramOnlineGreen = Color(0xFF4FA5E2)
val TelegramReplyAccent = Color(0xFF5288C1)
val TelegramCheckmarkBlue = Color(0xFF4FA5E2)

val TelegramDarkBubbleRam = Color(0xFF182533)
val TelegramDarkBubbleUser = Color(0xFF2B5278)
val TelegramLightBubbleRam = Color(0xFFFFFFFF)
val TelegramLightBubbleUser = Color(0xFFEEFFDE)

val SuccessGreen = Color(0xFF4CAF50)
val DangerRed = Color(0xFFE53935)

