package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.WebBridgeState
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TelegramDarkHeader
import com.example.ui.theme.TelegramOnlineGreen
import com.example.ui.theme.TelegramReplyAccent
import com.example.ui.viewmodel.RamViewModel

@Composable
fun SettingsScreen(
    viewModel: RamViewModel,
    onBack: () -> Unit
) {
    val isCloudConnected by viewModel.preferences.isCloudConnected.collectAsState()
    val userName by viewModel.preferences.userName.collectAsState()
    val userGender by viewModel.preferences.userGender.collectAsState()
    val apiKey by viewModel.preferences.apiKey.collectAsState()
    val sarcasmLevel by viewModel.preferences.sarcasmTolerance.collectAsState()
    val bridgeState by viewModel.webBridgeState.collectAsState()
    val bridgeLog by viewModel.webBridgeLog.collectAsState()
    val isTesting by viewModel.isTestingSession.collectAsState()
    val sessions by viewModel.sessions.collectAsState()

    var editName by remember(userName) { mutableStateOf(userName) }
    var editApiKey by remember(apiKey) { mutableStateOf(apiKey) }
    var sliderSarcasm by remember(sarcasmLevel) { mutableFloatStateOf(sarcasmLevel.toFloat()) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TelegramDarkHeader)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع للمحادثة",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "إدارة الجلسات والربط بالخلفية",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "المسار الثاني: متصفح خفي واختبار التنسيق الصارم",
                        color = Color(0xFFA0B0C0),
                        fontSize = 12.sp
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Section 1: Headless Bridge State & Testing
            Text(
                text = "حالة المتصفح الخفي (المسار الثاني)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val statusColor = when (bridgeState) {
                            WebBridgeState.SESSION_VERIFIED, WebBridgeState.LOGGED_IN_IDLE -> TelegramOnlineGreen
                            WebBridgeState.INJECTING_RAM_PERSONA, WebBridgeState.VALIDATING_FORMAT -> TelegramReplyAccent
                            WebBridgeState.FORMAT_ERROR_RETRYING -> Color(0xFFFF9800)
                            WebBridgeState.REQUIRES_LOGIN, WebBridgeState.ERROR -> DangerRed
                            else -> Color.Gray
                        }

                        Icon(
                            imageVector = if (isCloudConnected) Icons.Default.CloudDone else Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = statusColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            val stateLabel = when (bridgeState) {
                                WebBridgeState.SESSION_VERIFIED -> "الجلسة نشطة ومصادق عليها (JSON سليم)"
                                WebBridgeState.LOGGED_IN_IDLE -> "تسجيل الدخول نشط بالخلفية"
                                WebBridgeState.INJECTING_RAM_PERSONA -> "جاري إرسال وثيقة رام v4.0 للموقع..."
                                WebBridgeState.VALIDATING_FORMAT -> "جاري التحقق من التنسيق الصارم..."
                                WebBridgeState.FORMAT_ERROR_RETRYING -> "تنبيه: تم رصد خطأ تنسيق - جاري التصحيح الآلي..."
                                WebBridgeState.REQUIRES_LOGIN -> "بحاجة لتسجيل دخول لمرة واحدة"
                                WebBridgeState.LOADING_PAGE -> "جاري تحميل محرك الويب..."
                                WebBridgeState.ERROR -> "خطأ في الاتصال بالويب"
                                else -> "غير متصل"
                            }
                            Text(
                                text = stateLabel,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = statusColor
                            )
                            Text(
                                text = "المتصفح يعمل كـ Headless في الذاكرة دون أي إعلانات أو واجهات.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Live Log Terminal Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E2834))
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.BugReport,
                                contentDescription = null,
                                tint = Color(0xFF64B5F6),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = bridgeLog,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFE0E0E0),
                                maxLines = 3
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action Buttons for Testing & Creating Session
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.createAndInitializeNewSession() },
                            enabled = !isTesting,
                            colors = ButtonDefaults.buttonColors(containerColor = TelegramReplyAccent),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            if (isTesting) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                            } else {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text("جلسة جديدة + ملف رام", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.testCurrentSession() },
                            enabled = !isTesting,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("اختبار التنسيق", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (!isCloudConnected) {
                        Button(
                            onClick = { viewModel.showWebBrowser() },
                            colors = ButtonDefaults.buttonColors(containerColor = TelegramOnlineGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("فتح متصفح ديب سيك المباشر وتسجيل الدخول")
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.showWebBrowser() },
                                colors = ButtonDefaults.buttonColors(containerColor = TelegramReplyAccent),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("عرض المتصفح", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { viewModel.disconnectCloud() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("تسجيل الخروج", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 2: Active Sessions History
            Text(
                text = "سجل الجلسات ونتائج الاختبار",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    sessions.forEach { sess ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = sess.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "الحالة: ${sess.lastTestResult}",
                                    fontSize = 11.sp,
                                    color = if (sess.isFormatVerified) TelegramOnlineGreen else Color.Gray
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (sess.isActive) TelegramReplyAccent.copy(alpha = 0.2f) else Color.Gray.copy(alpha = 0.1f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (sess.isActive) "نشطة" else "سابقة",
                                    fontSize = 10.sp,
                                    color = if (sess.isActive) TelegramReplyAccent else Color.Gray
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 3: User Identity for Ram
            Text(
                text = "هوية المستخدم والمخاطبة",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = {
                            editName = it
                            viewModel.preferences.setUserName(it)
                        },
                        label = { Text("اسمك الذي تناديك به رام") },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("صيغة المخاطبة:", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row {
                        Button(
                            onClick = { viewModel.preferences.setUserGender("مذكر") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (userGender == "مذكر") TelegramReplyAccent else Color.Gray.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("مذكر")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { viewModel.preferences.setUserGender("مؤنث") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (userGender == "مؤنث") TelegramReplyAccent else Color.Gray.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("مؤنث")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 4: Sarcasm & Personality Tuning
            Text(
                text = "شخصية رام وسقف السخرية",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val label = when (sliderSarcasm.toInt()) {
                        0 -> "المستوى 0: بلا سخرية (بارد ومباشر)"
                        1 -> "المستوى 1: تلميح جاف وواقعي"
                        2 -> "المستوى 2: وخز صريح يسبق الحل"
                        else -> "المستوى 3: سخرية كاملة وشديدة الذكاء"
                    }
                    Text(text = label, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    Slider(
                        value = sliderSarcasm,
                        onValueChange = {
                            sliderSarcasm = it
                            viewModel.preferences.setSarcasmTolerance(it.toInt())
                        },
                        valueRange = 0f..3f,
                        steps = 2
                    )
                }
            }
        }
    }
}
