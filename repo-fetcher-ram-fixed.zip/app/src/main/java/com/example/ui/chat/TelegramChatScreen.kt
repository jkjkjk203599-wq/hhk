package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TelegramDarkBg
import com.example.ui.theme.TelegramDateChipBg
import com.example.ui.theme.TelegramLightBg
import com.example.ui.viewmodel.RamViewModel

@Composable
fun TelegramChatScreen(
    viewModel: RamViewModel,
    onNavigateToTasks: () -> Unit,
    onNavigateToDebts: () -> Unit,
    onNavigateToMemory: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val messages by viewModel.chatMessages.collectAsState()
    val isTyping by viewModel.isRamTyping.collectAsState()
    val isCloudConnected by viewModel.preferences.isCloudConnected.collectAsState()
    val selectedReply by viewModel.selectedReplyMessage.collectAsState()

    val listState = rememberLazyListState()
    val isDark = isSystemInDarkTheme()
    val chatBg = if (isDark) TelegramDarkBg else TelegramLightBg

    // Auto-scroll to bottom when messages update or typing starts
    LaunchedEffect(messages.size, isTyping) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TelegramChatTopBar(
                isTyping = isTyping,
                isCloudConnected = isCloudConnected,
                onOpenTasks = onNavigateToTasks,
                onOpenDebts = onNavigateToDebts,
                onOpenMemory = onNavigateToMemory,
                onOpenSettings = onNavigateToSettings,
                onOpenBrowser = { viewModel.showWebBrowser() },
                onClearChat = { viewModel.clearChat() }
            )
        },
        bottomBar = {
            TelegramInputBar(
                replyMessage = selectedReply,
                onCancelReply = { viewModel.clearReply() },
                onSendMessage = { text -> viewModel.sendMessage(text) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(chatBg)
                .padding(innerPadding)
                .testTag("chat_messages_container")
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 4.dp)
            ) {
                // Centered Date Chip
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(TelegramDateChipBg)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "اليوم",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                items(
                    items = messages,
                    key = { it.id }
                ) { msg ->
                    TelegramMessageBubble(
                        message = msg,
                        onReplyToMessage = { viewModel.setReplyTo(it) },
                        onConfirmAction = { viewModel.confirmAction(it) }
                    )
                }
            }
        }
    }
}
