package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.chat.TelegramChatScreen
import com.example.ui.debts.DebtsScreen
import com.example.ui.memory.MemoryScreen
import com.example.ui.settings.DeepSeekWebBrowserView
import com.example.ui.settings.SettingsScreen
import com.example.ui.tasks.TasksScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RamViewModel

enum class AppScreen {
    CHAT,
    TASKS,
    DEBTS,
    MEMORY,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RamApp()
                }
            }
        }
    }
}

@Composable
fun RamApp(viewModel: RamViewModel = viewModel()) {
    var currentScreen by remember { mutableStateOf(AppScreen.CHAT) }
    val isWebOverlayVisible by viewModel.isWebOverlayVisible.collectAsState()

    BackHandler(enabled = isWebOverlayVisible) {
        viewModel.hideWebBrowser()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (currentScreen) {
            AppScreen.CHAT -> {
                TelegramChatScreen(
                    viewModel = viewModel,
                    onNavigateToTasks = { currentScreen = AppScreen.TASKS },
                    onNavigateToDebts = { currentScreen = AppScreen.DEBTS },
                    onNavigateToMemory = { currentScreen = AppScreen.MEMORY },
                    onNavigateToSettings = { currentScreen = AppScreen.SETTINGS }
                )
            }

            AppScreen.TASKS -> {
                BackHandler { currentScreen = AppScreen.CHAT }
                TasksScreen(
                    viewModel = viewModel,
                    onBack = { currentScreen = AppScreen.CHAT }
                )
            }

            AppScreen.DEBTS -> {
                BackHandler { currentScreen = AppScreen.CHAT }
                DebtsScreen(
                    viewModel = viewModel,
                    onBack = { currentScreen = AppScreen.CHAT }
                )
            }

            AppScreen.MEMORY -> {
                BackHandler { currentScreen = AppScreen.CHAT }
                MemoryScreen(
                    viewModel = viewModel,
                    onBack = { currentScreen = AppScreen.CHAT }
                )
            }

            AppScreen.SETTINGS -> {
                BackHandler { currentScreen = AppScreen.CHAT }
                SettingsScreen(
                    viewModel = viewModel,
                    onBack = { currentScreen = AppScreen.CHAT }
                )
            }
        }

        // Single Persistent DeepSeek WebView in MainActivity Window hierarchy
        Box(
            modifier = Modifier
                .fillMaxSize()
                .zIndex(if (isWebOverlayVisible) 100f else -1f)
                .alpha(if (isWebOverlayVisible) 1f else 0.001f)
        ) {
            DeepSeekWebBrowserView(
                webBridge = viewModel.webBridge,
                onClose = { viewModel.hideWebBrowser() },
                onConfirmSession = {
                    viewModel.manualConfirmSession()
                    viewModel.hideWebBrowser()
                }
            )
        }
    }
}
