package com.example.domain.engine

import com.example.data.model.ChatMessageEntity
import com.example.data.model.DebtEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.MessageSender
import com.example.data.model.MessageStatus
import com.example.data.model.RamAction
import com.example.data.model.RamResponse
import com.example.data.model.TaskEntity
import com.example.data.repository.RamRepository
import com.example.data.repository.UserPreferencesRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.Date

class RamEngine(
    private val repository: RamRepository,
    private val preferencesRepository: UserPreferencesRepository,
    val bridge: DeepSeekBridge
) {
    private val _isRamTyping = MutableStateFlow(false)
    val isRamTyping: StateFlow<Boolean> = _isRamTyping.asStateFlow()

    suspend fun sendMessage(
        userText: String,
        replyToMessage: ChatMessageEntity? = null
    ) {
        val trimmed = userText.trim()
        if (trimmed.isBlank()) return

        // 1. Save User Message immediately to Room
        val userMsgId = repository.insertChatMessage(
            ChatMessageEntity(
                sender = MessageSender.USER,
                text = trimmed,
                replyToId = replyToMessage?.id,
                replyToText = replyToMessage?.text?.take(80),
                replyToSender = replyToMessage?.sender,
                status = MessageStatus.SENT
            )
        )

        _isRamTyping.value = true

        try {
            // 2. Fetch current database state for prompt injection
            val currentTasks = repository.getAllTasks()
            val currentDebts = repository.getAllDebts()
            val currentMemories = repository.getAllMemories()
            val userName = preferencesRepository.userName.value
            val userGender = preferencesRepository.userGender.value

            // Recent history
            val recentMessages = repository.getRecentMessages(6)
            // The current user message is already present in [USER] below; do not send it twice.
            // Repository returns the list in chronological order for prompt construction.
            val historyPairs = recentMessages.dropLast(1).map {
                val senderStr = if (it.sender == MessageSender.USER) "USER" else "RAM"
                senderStr to it.text
            }

            // 3. Build prompts
            val systemPrompt = RamPromptBuilder.buildSystemPrompt(userName, userGender)
            val contextBlocks = RamPromptBuilder.buildContextBlocks(
                now = Date(),
                tasks = currentTasks,
                debts = currentDebts,
                memories = currentMemories,
                plans = emptyList(),
                userMessage = trimmed,
                replyToText = replyToMessage?.text,
                conversationsCount = recentMessages.size,
                relationshipStage = preferencesRepository.sarcasmTolerance.value
            )

            // 4. Send via DeepSeekBridge (Persistent Web Bridge or fallback)
            val parsedResponse = bridge.sendPrompt(systemPrompt, contextBlocks, historyPairs)

            // 5. Deliver messages sequentially with human-like Telegram rhythm
            deliverRamResponse(parsedResponse, replyToMessage)

            // 6. Apply Memory Writes
            parsedResponse.memoryWrites.forEach { mem ->
                repository.insertMemory(
                    MemoryEntity(
                        key = mem.key,
                        type = mem.type,
                        value = mem.value,
                        confidence = mem.confidence,
                        source = mem.source,
                        date = mem.date.ifBlank { System.currentTimeMillis().toString() }
                    )
                )
            }

            // 7. Auto-execute unconfirmed actions
            executeDirectActions(parsedResponse.actions)

        } catch (e: Exception) {
            repository.insertChatMessage(
                ChatMessageEntity(
                    sender = MessageSender.RAM,
                    text = "صار في بطء بسيط بالاتصال. بس أنا هون، شو كنت عم تقول؟",
                    status = MessageStatus.READ
                )
            )
        } finally {
            _isRamTyping.value = false
        }
    }

    private suspend fun deliverRamResponse(
        response: RamResponse,
        replyToMessage: ChatMessageEntity?
    ) {
        val totalMessages = response.messages.size

        response.messages.forEachIndexed { index, msg ->
            _isRamTyping.value = true
            val waitTime = msg.delayMs.coerceIn(300L, 2500L)
            delay(waitTime)

            val pendingAction = response.actions.find { it.requiresConfirmation }
            val actionJson = if (pendingAction != null && index == (pendingAction.confirmationPromptIndex ?: (totalMessages - 1))) {
                serializeAction(pendingAction)
            } else null

            val quote = response.quotes.find { it.afterMessageIndex == index }

            repository.insertChatMessage(
                ChatMessageEntity(
                    sender = MessageSender.RAM,
                    text = msg.text,
                    replyToId = if (index == 0) replyToMessage?.id else null,
                    replyToText = if (index == 0) replyToMessage?.text?.take(80) else null,
                    replyToSender = if (index == 0) replyToMessage?.sender else null,
                    status = MessageStatus.READ,
                    thinking = if (index == 0) response.thinking else null,
                    sarcasmLevel = response.sarcasmLevel,
                    userState = response.userState,
                    pendingActionJson = actionJson,
                    quoteText = quote?.text
                )
            )

            if (index < totalMessages - 1) {
                delay(300L)
            }
        }
    }

    private suspend fun executeDirectActions(actions: List<RamAction>) {
        actions.filter { !it.requiresConfirmation }.forEach { action ->
            when (action.type) {
                "create_task" -> {
                    val title = action.params["title"]?.toString() ?: "مهمة جديدة"
                    val due = action.params["due"]?.toString() ?: "اليوم"
                    val priority = action.params["priority"]?.toString() ?: "متوسطة"
                    val duration = action.params["estimatedDuration"]?.toString() ?: "30د"
                    repository.insertTask(
                        TaskEntity(
                            taskCode = "t${System.currentTimeMillis() % 1000}",
                            title = title,
                            due = due,
                            priority = priority,
                            estimatedDuration = duration,
                            status = "لم تبدأ"
                        )
                    )
                }
                "complete_task" -> {
                    val taskId = action.params["task_id"]?.toString() ?: ""
                    val task = repository.getTaskByIdOrCode(taskId.toLongOrNull() ?: -1L, taskId)
                    if (task != null) {
                        repository.updateTask(task.copy(status = "منجزة"))
                    }
                }
            }
        }
    }

    suspend fun confirmAction(actionJson: String) {
        try {
            val json = JSONObject(actionJson)
            val type = json.optString("type")
            val paramsObj = json.optJSONObject("params") ?: JSONObject()

            when (type) {
                "add_debt" -> {
                    val party = paramsObj.optString("party", "صديق")
                    val amount = paramsObj.optDouble("amount", 0.0)
                    val currency = paramsObj.optString("currency", "USD")
                    val direction = paramsObj.optString("direction", "لي")
                    val due = paramsObj.optString("due", "")
                    val notes = paramsObj.optString("notes", "")

                    repository.insertDebt(
                        DebtEntity(
                            debtCode = "d${System.currentTimeMillis() % 1000}",
                            party = party,
                            amount = amount,
                            currency = currency,
                            direction = direction,
                            dueDate = due,
                            notes = notes,
                            debtDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH).format(Date())
                        )
                    )

                    repository.insertChatMessage(
                        ChatMessageEntity(
                            sender = MessageSender.RAM,
                            text = "سجلت الدين بالدفتر: $amount $currency ($party). الأمور موثقة هلق.",
                            status = MessageStatus.READ
                        )
                    )
                }
                "delete_task" -> {
                    val taskId = paramsObj.optString("task_id", "")
                    repository.deleteTaskByIdOrCode(taskId.toLongOrNull() ?: -1L, taskId)
                    repository.insertChatMessage(
                        ChatMessageEntity(
                            sender = MessageSender.RAM,
                            text = "انشطبت المهمة من القائمة.",
                            status = MessageStatus.READ
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Ignore error
        }
    }

    private fun serializeAction(action: RamAction): String {
        val json = JSONObject()
        json.put("type", action.type)
        val paramsJson = JSONObject()
        action.params.forEach { (k, v) -> paramsJson.put(k, v) }
        json.put("params", paramsJson)
        json.put("requires_confirmation", action.requiresConfirmation)
        return json.toString()
    }
}
