package com.example.domain.engine

import android.content.Context
import android.util.Log
import com.example.data.model.RamMessage
import com.example.data.model.RamResponse
import com.example.data.repository.UserPreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class DeepSeekBridge(
    private val context: Context,
    private val preferencesRepository: UserPreferencesRepository,
    val webBridge: DeepSeekWebBridge
) {
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun sendPrompt(
        systemPrompt: String,
        contextPrompt: String,
        recentHistory: List<Pair<String, String>> = emptyList()
    ): RamResponse = withContext(Dispatchers.IO) {
        val apiKey = preferencesRepository.apiKey.value
        val isCloudConnected = preferencesRepository.isCloudConnected.value

        // 1. Path 2: Persistent Live Headless Web Bridge (Primary)
        if (isCloudConnected) {
            try {
                val webResponse = webBridge.executeRamTurn(systemPrompt, contextPrompt, recentHistory)
                if (webResponse.confidence > 0.0 && webResponse.messages.isNotEmpty()) {
                    return@withContext webResponse
                }
            } catch (e: Exception) {
                Log.e("DeepSeekBridge", "Headless web execution error", e)
            }
        }

        // 2. Direct API if API key provided
        if (apiKey.isNotBlank()) {
            try {
                val apiRaw = callDeepSeekApi(apiKey, systemPrompt, contextPrompt, recentHistory)
                if (apiRaw.isNotBlank()) {
                    return@withContext RamResponseParser.parse(apiRaw)
                }
            } catch (e: Exception) {
                Log.e("DeepSeekBridge", "API call failed", e)
            }
        }

        // 3. If Not Connected: Real honest failure (NO FAKE OFFLINE SIMULATION)
        RamResponse(
            thinking = "الاتصال بديب سيك غير مفعل حالياً.",
            messages = listOf(
                RamMessage(
                    text = "⚠️ لم يتم تفعيل الجلسة مع ديب سيك بعد.\nيرجى فتح الإعدادات ⬅️ 'فتح نافذة تسجيل الدخول' ⬅️ ثم الضغط على 'اعتماد الجلسة الآن' لتبدأ باستلام ردود ديب سيك الحقيقية.",
                    delayMs = 400L
                )
            ),
            confidence = 0.0
        )
    }

    private fun callDeepSeekApi(
        token: String,
        systemPrompt: String,
        userPrompt: String,
        history: List<Pair<String, String>>
    ): String {
        val jsonMediaType = "application/json; charset=utf-8".toMediaType()

        val messagesArray = JSONArray()
        messagesArray.put(JSONObject().apply {
            put("role", "system")
            put("content", systemPrompt)
        })

        history.takeLast(6).forEach { (sender, text) ->
            val role = if (sender == "USER") "user" else "assistant"
            messagesArray.put(JSONObject().apply {
                put("role", role)
                put("content", text)
            })
        }

        messagesArray.put(JSONObject().apply {
            put("role", "user")
            put("content", userPrompt)
        })

        val requestJson = JSONObject().apply {
            put("model", "deepseek-chat")
            put("messages", messagesArray)
            put("temperature", 0.7)
            put("response_format", JSONObject().apply {
                put("type", "json_object")
            })
        }

        val request = Request.Builder()
            .url("https://api.deepseek.com/chat/completions")
            .header("Authorization", "Bearer $token")
            .header("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        val response = okHttpClient.newCall(request).execute()
        val body = response.body?.string() ?: ""

        if (!response.isSuccessful) {
            throw Exception("DeepSeek API error: ${response.code} $body")
        }

        val resObj = JSONObject(body)
        val choices = resObj.getJSONArray("choices")
        if (choices.length() > 0) {
            val message = choices.getJSONObject(0).getJSONObject("message")
            return message.getString("content")
        }
        return ""
    }
}
