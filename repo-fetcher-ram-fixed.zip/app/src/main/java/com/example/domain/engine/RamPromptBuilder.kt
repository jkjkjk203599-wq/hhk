package com.example.domain.engine

import com.example.data.model.DebtEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.PlanEntity
import com.example.data.model.TaskEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object RamPromptBuilder {

    fun buildSystemPrompt(
        userName: String = "سامر",
        userGender: String = "مذكر"
    ): String {
        return """
أنتِ «رام» (الإصدار 4.0 - النسخة النهائية). مستشارة شخصية لـ $userName داخل تطبيق يدير حياته (التخطيط، المهام، الوقت، والديون).
خاطبي المستخدم دائماً بـ: $userName (الجنس: $userGender).

شخصيتك:
- باردة، ساخرة، صادقة، فخورة، مخلصة بصمت، وكسولة انتقائياً (أقل جهد وأعلى دقة).
- لهجتك: عامية سورية (شامية) خفيفة وواضحة ومفهومة. فصحى فقط في الجدية التامة أو الاقتباس أو السخرية بالفخامة.
- أسلوبك: رسائل قصيرة، كل فكرة في رسالة مستقلة. لا Markdown عريض ولا عناوين ضخمة. النقطة سلاحك المفضل.
- ممنوع كسر الشخصية، وممنوع عبارات التحفيز الرخيصة أو الافتتاحيات والاعتذارات الآلية، ولا إيموجيات مبتهجة. الإيموجي نادر جداً وبسخرية جافة فقط (😒 🙄 😑 😐 ☕).
- نقد إجباري لأي خطة غير واقعية. لا تعطي أوهاماً، بل خطوات عملية صغيرة قابلة للتنفيذ.

بروتوكول الإخراج (JSON صارم وحصري):
يجب أن يكون ردك عبارة عن كائن JSON واحد صالح فقط دون أي نص قبله أو بعده، وبدون علامات markdown (لا تضعي ```json):
{
  "thinking": "خلاصة تفكيرك الداخلي المختزل (أمان، نية، حالة، مرحلة، درجة سخرية)",
  "sarcasm_level": 1,
  "user_state": "حالة المستخدم الحالية",
  "relationship_stage": 1,
  "messages": [
    {
      "text": "نص الرسالة الأولى بالعامية السورية كما يراها المستخدم",
      "delay_ms": 700
    }
  ],
  "quotes": [],
  "actions": [],
  "memory_writes": [],
  "confidence": 1.0,
  "followups": []
}

الأفعال المتاحة في حقل actions:
- create_task: params { title, due, priority, estimatedDuration }
- update_task: params { task_id, fields }
- complete_task: params { task_id }
- delete_task: params { task_id } (confirm: true)
- add_debt: params { party, amount, currency, direction, due, notes } (confirm: true)
- update_debt: params { debt_id, fields } (confirm: true)
- settle_debt: params { debt_id, amount } (confirm: true)
- delete_debt: params { debt_id } (confirm: true)
- create_plan: params { title, goal, steps }
- note: params { text }
- forget_memory: params { key } (confirm: true)

ملاحظة الأفعال الحساسة (المال والحذف): ضعي requires_confirmation = true و confirmation_prompt_index يشير إلى رقم الرسالة التي تسألينه فيها للتأكيد.
        """.trimIndent()
    }

    fun buildContextBlocks(
        now: Date = Date(),
        tasks: List<TaskEntity>,
        debts: List<DebtEntity>,
        memories: List<MemoryEntity>,
        plans: List<PlanEntity>,
        userMessage: String,
        replyToText: String? = null,
        conversationsCount: Int = 1,
        relationshipStage: Int = 1
    ): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        val dayFormat = SimpleDateFormat("EEEE", Locale("ar"))
        val timeFormat = SimpleDateFormat("HH:mm", Locale.ENGLISH)

        val dateStr = dateFormat.format(now)
        val dayStr = dayFormat.format(now)
        val timeStr = timeFormat.format(now)

        val sb = StringBuilder()

        // [NOW]
        sb.appendLine("[NOW]")
        sb.appendLine("التاريخ: $dateStr")
        sb.appendLine("اليوم: $dayStr")
        sb.appendLine("الوقت: $timeStr")
        sb.appendLine("[/NOW]\n")

        // [TASKS]
        sb.appendLine("[TASKS]")
        if (tasks.isEmpty()) {
            sb.appendLine("لا توجد مهام مسجلة حالياً.")
        } else {
            sb.appendLine("id | العنوان | الموعد | الحالة | الأولوية | المدة_المقدرة | مرات_التأجيل | تاريخ_الإنشاء")
            tasks.forEach { t ->
                val code = if (t.taskCode.isNotBlank()) t.taskCode else "t${t.id}"
                sb.appendLine("$code | ${t.title} | ${t.due.ifBlank { "غير محدد" }} | ${t.status} | ${t.priority} | ${t.estimatedDuration} | ${t.postponesCount} | $dateStr")
            }
        }
        sb.appendLine("[/TASKS]\n")

        // [DEBTS]
        sb.appendLine("[DEBTS]")
        if (debts.isEmpty()) {
            sb.appendLine("دفتر الديون فارغ.")
        } else {
            sb.appendLine("id | الشخص | الاتجاه | المبلغ | العملة | المسدد | تاريخ_الدين | تاريخ_الاستحقاق | ملاحظات")
            debts.forEach { d ->
                val code = if (d.debtCode.isNotBlank()) d.debtCode else "d${d.id}"
                sb.appendLine("$code | ${d.party} | ${d.direction} | ${d.amount} | ${d.currency} | ${d.paidAmount} | ${d.debtDate} | ${d.dueDate} | ${d.notes}")
            }
        }
        sb.appendLine("[/DEBTS]\n")

        // [MEMORY]
        sb.appendLine("[MEMORY]")
        sb.appendLine("relationship_stage: $relationshipStage")
        sb.appendLine("conversations_count: $conversationsCount")
        sb.appendLine("facts:")
        memories.filter { it.type in listOf("fact", "preference", "goal", "relationship") }.forEach { m ->
            sb.appendLine("- ${m.key}: ${m.value}")
        }
        val recentMemories = memories.filter { it.type in listOf("advice_given", "advice_outcome", "correction") }
        if (recentMemories.isNotEmpty()) {
            sb.appendLine("recent:")
            recentMemories.forEach { m ->
                sb.appendLine("- ${m.key}: ${m.value}")
            }
        }
        sb.appendLine("[/MEMORY]\n")

        // [INDEX]
        if (plans.isNotEmpty()) {
            sb.appendLine("[INDEX]")
            sb.appendLine("الخطط المسجلة:")
            plans.forEach { p ->
                val code = if (p.planCode.isNotBlank()) p.planCode else "p${p.id}"
                sb.appendLine("- $code: ${p.title} (الهدف: ${p.goal})")
            }
            sb.appendLine("[/INDEX]\n")
        }

        // [USER]
        sb.appendLine("[USER]")
        if (!replyToText.isNullOrBlank()) {
            sb.appendLine("(رد على الرسالة: \"$replyToText\")")
        }
        sb.appendLine(userMessage)
        sb.appendLine("[/USER]")

        return sb.toString()
    }
}
