package com.example.domain.engine

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.http.SslError
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.model.RamMessage
import com.example.data.model.RamResponse
import com.example.data.repository.UserPreferencesRepository
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class WebBridgeState {
    NOT_INITIALIZED,
    LOADING_PAGE,
    REQUIRES_LOGIN,
    LOGGED_IN_IDLE,
    INJECTING_RAM_PERSONA,
    SESSION_VERIFIED,
    SENDING_PROMPT,
    RECEIVING_RESPONSE,
    VALIDATING_FORMAT,
    FORMAT_ERROR_RETRYING,
    ERROR
}

enum class ConsoleLogLevel {
    ERROR,
    WARNING,
    INFO,
    DEBUG,
    LOG,
    NETWORK,
    DOM_PROTECT,
    JS_EVAL
}

data class WebConsoleEntry(
    val id: Long = System.currentTimeMillis() + (0..999).random(),
    val level: ConsoleLogLevel,
    val message: String,
    val source: String = "",
    val lineNumber: Int = 0,
    val timestamp: String = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
)

class DeepSeekWebBridge(
    private val context: Context,
    private val preferencesRepository: UserPreferencesRepository
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main)
    var sharedWebView: WebView? = null
        private set

    private val htmlClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val _bridgeState = MutableStateFlow(WebBridgeState.NOT_INITIALIZED)
    val bridgeState: StateFlow<WebBridgeState> = _bridgeState.asStateFlow()

    private val _currentUrl = MutableStateFlow(DEEPSEEK_CHAT_URL)
    val currentUrl: StateFlow<String> = _currentUrl.asStateFlow()

    private val _pageTitle = MutableStateFlow("ديب سيك ويب")
    val pageTitle: StateFlow<String> = _pageTitle.asStateFlow()

    private val _lastLog = MutableStateFlow("تهيئة المتصفح ونظام الحماية المباشر...")
    val lastLog: StateFlow<String> = _lastLog.asStateFlow()

    private val _hasInputField = MutableStateFlow(false)
    val hasInputField: StateFlow<Boolean> = _hasInputField.asStateFlow()

    private val _lastRawOutput = MutableStateFlow("")
    val lastRawOutput: StateFlow<String> = _lastRawOutput.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _loadProgress = MutableStateFlow(0)
    val loadProgress: StateFlow<Int> = _loadProgress.asStateFlow()

    private val _canGoBack = MutableStateFlow(false)
    val canGoBack: StateFlow<Boolean> = _canGoBack.asStateFlow()

    private val _canGoForward = MutableStateFlow(false)
    val canGoForward: StateFlow<Boolean> = _canGoForward.asStateFlow()

    private val _isDesktopMode = MutableStateFlow(false)
    val isDesktopMode: StateFlow<Boolean> = _isDesktopMode.asStateFlow()

    // Interactive DevTools Console Logs
    private val _consoleLogs = MutableStateFlow<List<WebConsoleEntry>>(emptyList())
    val consoleLogs: StateFlow<List<WebConsoleEntry>> = _consoleLogs.asStateFlow()

    private var activeResponseDeferred: CompletableDeferred<String>? = null
    var onExternalUserPromptHandler: (suspend (String) -> RamResponse)? = null

    companion object {
        private const val TAG = "DeepSeekWebBridge"
        const val DEEPSEEK_CHAT_URL = "https://chat.deepseek.com/"
        const val DEEPSEEK_LOGIN_URL = "https://chat.deepseek.com/sign_in"
        const val LOCAL_REACT_CLIENT_URL = "file:///android_asset/web/index.html"
        const val GOOGLE_URL = "https://www.google.com/"
        const val CLOUDFLARE_TEST_URL = "https://www.cloudflare.com/"
        const val EXAMPLE_URL = "https://example.com/"

        const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36"
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
    }

    init {
        mainHandler.post {
            createOrGetWebView()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun createOrGetWebView(overrideContext: Context? = null): WebView {
        val targetContext = overrideContext ?: context

        if (sharedWebView != null && overrideContext != null && sharedWebView?.context !is android.app.Activity && overrideContext is android.app.Activity) {
            try {
                sharedWebView?.destroy()
            } catch (e: Exception) {
                Log.w(TAG, "Error destroying old webview", e)
            }
            sharedWebView = null
        }

        sharedWebView?.let { return it }

        _bridgeState.value = WebBridgeState.LOADING_PAGE
        addConsoleLog(ConsoleLogLevel.DOM_PROTECT, "بدء تشغيل محرك المتصفح وتثبيت دروع حماية الـ DOM وعناصر الشات...")

        val wv = WebView(targetContext).apply {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

                useWideViewPort = true
                loadWithOverviewMode = false

                javaScriptCanOpenWindowsAutomatically = true
                setSupportMultipleWindows(false)

                allowFileAccess = true
                allowContentAccess = true
                cacheMode = WebSettings.LOAD_DEFAULT

                builtInZoomControls = true
                displayZoomControls = false
                setSupportZoom(true)
                textZoom = 100
                layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL
                mediaPlaybackRequiresUserGesture = false

                userAgentString = if (_isDesktopMode.value) DESKTOP_USER_AGENT else MOBILE_USER_AGENT
            }

            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            cookieManager.setAcceptThirdPartyCookies(this, true)

            addJavascriptInterface(JsInterface(), "AndroidBridge")

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    super.onProgressChanged(view, newProgress)
                    _loadProgress.value = newProgress
                    _isLoading.value = newProgress < 100

                    if (newProgress in 15..95) {
                        injectEarlyProtectionScript(view)
                    }
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    super.onReceivedTitle(view, title)
                    _pageTitle.value = title ?: ""
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    try {
                        request?.grant(request.resources)
                        addConsoleLog(ConsoleLogLevel.INFO, "تم منح إذن النظام: ${request?.resources?.joinToString()}")
                    } catch (e: Exception) {
                        Log.w(TAG, "Permission request error", e)
                    }
                }

                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    consoleMessage?.let {
                        val level = when (it.messageLevel()) {
                            ConsoleMessage.MessageLevel.ERROR -> ConsoleLogLevel.ERROR
                            ConsoleMessage.MessageLevel.WARNING -> ConsoleLogLevel.WARNING
                            ConsoleMessage.MessageLevel.TIP -> ConsoleLogLevel.INFO
                            ConsoleMessage.MessageLevel.DEBUG -> ConsoleLogLevel.DEBUG
                            else -> ConsoleLogLevel.LOG
                        }
                        val source = it.sourceId()?.substringAfterLast("/") ?: ""
                        addConsoleLog(level, it.message(), source, it.lineNumber())
                    }
                    return super.onConsoleMessage(consoleMessage)
                }
            }

            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    _isLoading.value = true
                    val u = url ?: ""
                    _currentUrl.value = u
                    _canGoBack.value = view?.canGoBack() == true
                    _canGoForward.value = view?.canGoForward() == true
                    addConsoleLog(ConsoleLogLevel.NETWORK, "بدء تحميل الرابط: $u")

                    injectEarlyProtectionScript(view)
                }

                override fun onPageCommitVisible(view: WebView?, url: String?) {
                    super.onPageCommitVisible(view, url)
                    injectEarlyProtectionScript(view)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    _isLoading.value = false
                    val u = url ?: ""
                    _currentUrl.value = u
                    _canGoBack.value = view?.canGoBack() == true
                    _canGoForward.value = view?.canGoForward() == true
                    addConsoleLog(ConsoleLogLevel.NETWORK, "اكتمل تحميل الرابط: $u")

                    CookieManager.getInstance().flush()
                    injectEarlyProtectionScript(view)
                    injectAutomationBridge()
                    syncSessionState()
                }

                // Do not proxy or rewrite DeepSeek traffic here. WebView must own the
                // complete browser session (redirects, Set-Cookie, POST bodies, WAF and
                // dynamically versioned JS assets). Rewriting these responses makes the
                // React app go blank immediately after authentication.
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    return super.shouldInterceptRequest(view, request)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val nextUrl = request?.url?.toString() ?: ""
                    _currentUrl.value = nextUrl

                    if (nextUrl.startsWith("http://") || nextUrl.startsWith("https://") ||
                        nextUrl.startsWith("file://") || nextUrl.startsWith("about:") || nextUrl.startsWith("data:")
                    ) {
                        return false
                    }

                    try {
                        val intent = Intent(Intent.ACTION_VIEW, request?.url)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        targetContext.startActivity(intent)
                    } catch (e: Exception) {
                        addConsoleLog(ConsoleLogLevel.WARNING, "مخطط خارجي تم تجاوزه بأمان: $nextUrl")
                    }
                    return true
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                    addConsoleLog(ConsoleLogLevel.WARNING, "SSL Notice: ${error?.primaryError} - متابعة التحميل لتفادي التوقف")
                    handler?.proceed()
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    super.onReceivedError(view, request, error)
                    val desc = error?.description?.toString() ?: "Unknown error"
                    val code = error?.errorCode ?: 0
                    val url = request?.url?.toString() ?: ""
                    addConsoleLog(ConsoleLogLevel.ERROR, "خطأ في تحميل المورد: $desc (كود: $code) - الرابط: $url")
                }

                override fun onReceivedHttpError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    errorResponse: WebResourceResponse?
                ) {
                    super.onReceivedHttpError(view, request, errorResponse)
                    val status = errorResponse?.statusCode ?: 0
                    val phrase = errorResponse?.reasonPhrase ?: ""
                    val url = request?.url?.toString() ?: ""
                    addConsoleLog(ConsoleLogLevel.ERROR, "خطأ HTTP $status $phrase - الرابط: $url")
                }

                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    addConsoleLog(ConsoleLogLevel.ERROR, "تحذير: توقف رندر المتصفح، جاري إعادة التهيئة...")
                    sharedWebView = null
                    mainHandler.post {
                        createOrGetWebView(targetContext)
                    }
                    return true
                }
            }

            loadUrl(DEEPSEEK_CHAT_URL)
        }

        sharedWebView = wv
        return wv
    }

    /**
     * Keep page diagnostics only. Do not patch DeepSeek's DOM, CSS, SRI checks,
     * MutationObserver or replaceChildren: those are part of its React bootstrap
     * and blocking them produces the post-login dark/empty screen.
     */
    private fun injectEarlyProtectionScript(view: WebView?) {
        val js = """
            (function() {
                if (window.__androidDiagnosticsAttached) return;
                window.__androidDiagnosticsAttached = true;
                window.addEventListener('error', function(e) {
                    if (window.AndroidBridge && window.AndroidBridge.onDevToolsLog) {
                        window.AndroidBridge.onDevToolsLog(
                            'ERROR',
                            (e.message || 'Script error') + ' at ' + (e.filename || '') + ':' + (e.lineno || 0),
                            e.filename || '', e.lineno || 0
                        );
                    }
                });
                window.addEventListener('unhandledrejection', function(e) {
                    if (window.AndroidBridge && window.AndroidBridge.onDevToolsLog) {
                        var reason = e.reason ? (e.reason.message || String(e.reason)) : 'Unhandled Promise Rejection';
                        window.AndroidBridge.onDevToolsLog('ERROR', 'Unhandled Rejection: ' + reason, 'PROMISE', 0);
                    }
                });
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    fun addConsoleLog(level: ConsoleLogLevel, message: String, source: String = "", lineNumber: Int = 0) {
        val entry = WebConsoleEntry(
            level = level,
            message = message,
            source = source,
            lineNumber = lineNumber
        )
        val current = _consoleLogs.value
        _consoleLogs.value = (current + entry).takeLast(250)

        if (level == ConsoleLogLevel.ERROR) {
            _lastLog.value = "⚠️ $message"
        } else if (level == ConsoleLogLevel.DOM_PROTECT) {
            _lastLog.value = "🛡️ $message"
        } else if (level == ConsoleLogLevel.NETWORK) {
            _lastLog.value = message
        }
    }

    fun clearConsoleLogs() {
        _consoleLogs.value = emptyList()
    }

    fun evaluateUserJs(code: String) {
        mainHandler.post {
            addConsoleLog(ConsoleLogLevel.JS_EVAL, "> $code", "USER_EVAL", 0)
            sharedWebView?.evaluateJavascript(code) { result ->
                addConsoleLog(ConsoleLogLevel.INFO, "< $result", "JS_RESULT", 0)
            }
        }
    }

    fun runLiveDomInspection() {
        mainHandler.post {
            val js = """
                (function() {
                    try {
                        const root = document.getElementById('root');
                        const rootExists = !!root;
                        const rootChildren = root ? root.children.length : 0;
                        const rootTextLen = root ? (root.textContent || '').trim().length : 0;
                        const rootDisplay = root ? window.getComputedStyle(root).display : 'none';

                        const inputs = document.querySelectorAll('textarea, input[name="search"], input[type="text"]');
                        const sriError = !!document.querySelector('div._sri-ck');
                        const cfOverlay = document.getElementById('cf-overlay');
                        const cfOverlayVisible = cfOverlay ? (window.getComputedStyle(cfOverlay).display !== 'none') : false;
                        const hasToken = !!localStorage.getItem('userToken');

                        const report = JSON.stringify({
                            url: location.href,
                            title: document.title,
                            rootExists: rootExists,
                            rootChildren: rootChildren,
                            rootTextLen: rootTextLen,
                            rootDisplay: rootDisplay,
                            rootInnerText: root ? (root.innerText || '').replace(/\s+/g, ' ').trim().substring(0, 150) : '',
                            rootRect: root ? { w: Math.round(root.getBoundingClientRect().width), h: Math.round(root.getBoundingClientRect().height) } : null,
                            inputsCount: inputs.length,
                            sriErrorPresent: sriError,
                            cfOverlayVisible: cfOverlayVisible,
                            hasUserToken: hasToken
                        });
                        return report;
                    } catch(e) {
                        return JSON.stringify({ error: e.message });
                    }
                })();
            """.trimIndent()

            sharedWebView?.evaluateJavascript(js) { res ->
                try {
                    val cleanJson = if (res.startsWith("\"") && res.endsWith("\"")) {
                        res.substring(1, res.length - 1).replace("\\\"", "\"").replace("\\\\", "\\")
                    } else res

                    val obj = JSONObject(cleanJson)
                    val rectObj = obj.optJSONObject("rootRect")
                    val dimensions = if (rectObj != null) "${rectObj.optInt("w")}x${rectObj.optInt("h")}px" else "غير محدد"
                    val visibleText = obj.optString("rootInnerText")

                    val reportText = buildString {
                        append("🔍 فحص عناصر الشات المباشر:")
                        append("\n• الرابط: ").append(obj.optString("url"))
                        append("\n• عنصر #root: ").append(if (obj.optBoolean("rootExists")) "موجود (أبعاد: $dimensions, أبناء: ${obj.optInt("rootChildren")})" else "❌ مفقود!")
                        if (visibleText.isNotBlank()) {
                            append("\n• النص الظاهر بالشات: \"").append(visibleText).append("\"")
                        }
                        append("\n• حقول الإدخال/Textarea: ").append(if (obj.optInt("inputsCount") > 0) "✅ موجودة (${obj.optInt("inputsCount")})" else "❌ غير موجودة")
                        append("\n• خطأ _sri-ck: ").append(if (obj.optBoolean("sriErrorPresent")) "⚠️ نشط ويخفي الصفحة!" else "✅ نظيف")
                        append("\n• طبقة Cloudflare Turnstile: ").append(if (obj.optBoolean("cfOverlayVisible")) "⚠️ حاجبة للشاشة" else "✅ غير نشطة")
                        append("\n• توكن الجلسة (userToken): ").append(if (obj.optBoolean("hasUserToken")) "✅ متوفر في التخزين" else "❌ غير مسجل")
                    }
                    addConsoleLog(ConsoleLogLevel.DOM_PROTECT, reportText, "INSPECTOR", 0)
                } catch (e: Exception) {
                    addConsoleLog(ConsoleLogLevel.INFO, "تقرير الفحص: $res", "INSPECTOR", 0)
                }
            }
        }
    }

    fun forceRestoreChatElements() {
        mainHandler.post {
            val js = """
                (function() {
                    try {
                        const sri = document.querySelector('div._sri-ck');
                        if (sri) { sri.remove(); }
                        const cf = document.getElementById('cf-overlay');
                        if (cf) { cf.style.display = 'none'; }
                        const root = document.getElementById('root');
                        if (root) {
                            root.style.display = 'block';
                            root.style.visibility = 'visible';
                            root.style.opacity = '1';
                            root.style.minHeight = '100vh';
                            root.style.width = '100%';
                        }
                        const appH = (window.innerHeight || document.documentElement.clientHeight) + 'px';
                        document.documentElement.style.setProperty('--app-height', appH);
                        if (document.body) {
                            document.body.style.setProperty('--app-height', appH);
                            document.body.style.minHeight = '100vh';
                        }
                        window.dispatchEvent(new Event('resize'));
                        return 'تم استعادة ظهور العناصر وتحديث قياسات الشاشة';
                    } catch(e) {
                        return 'فشل: ' + e.message;
                    }
                })();
            """.trimIndent()
            sharedWebView?.evaluateJavascript(js) { res ->
                addConsoleLog(ConsoleLogLevel.DOM_PROTECT, "استعادة العناصر: $res", "FORCE_RESTORE", 0)
            }
        }
    }

    fun loadUrl(urlInput: String) {
        mainHandler.post {
            val trimmed = urlInput.trim()
            if (trimmed.isEmpty()) return@post
            val targetUrl = when {
                trimmed.startsWith("file://") -> trimmed
                trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
                trimmed.startsWith("www.") -> "https://$trimmed"
                trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
                else -> "https://www.google.com/search?q=" + URLEncoder.encode(trimmed, "UTF-8")
            }
            log("فتح الرابط: $targetUrl")
            createOrGetWebView().loadUrl(targetUrl)
        }
    }

    fun loadLocalReactClient() {
        loadUrl(LOCAL_REACT_CLIENT_URL)
        addConsoleLog(ConsoleLogLevel.INFO, "تم تحميل عميل React/Next المدمج المباشر")
    }

    fun loadChatPage() {
        loadUrl(DEEPSEEK_CHAT_URL)
    }

    fun loadSignInPage() {
        loadUrl(DEEPSEEK_LOGIN_URL)
    }

    fun loadGoogle() {
        loadUrl(GOOGLE_URL)
    }

    fun loadCloudflareTest() {
        loadUrl(CLOUDFLARE_TEST_URL)
    }

    fun loadExample() {
        loadUrl(EXAMPLE_URL)
    }

    fun goBack() {
        mainHandler.post {
            if (sharedWebView?.canGoBack() == true) {
                sharedWebView?.goBack()
            }
        }
    }

    fun goForward() {
        mainHandler.post {
            if (sharedWebView?.canGoForward() == true) {
                sharedWebView?.goForward()
            }
        }
    }

    fun reload() {
        mainHandler.post {
            addConsoleLog(ConsoleLogLevel.NETWORK, "إعادة تحميل الصفحة...")
            sharedWebView?.reload()
        }
    }

    fun stopLoading() {
        mainHandler.post {
            sharedWebView?.stopLoading()
            _isLoading.value = false
        }
    }

    fun toggleDesktopMode() {
        mainHandler.post {
            val next = !_isDesktopMode.value
            _isDesktopMode.value = next
            sharedWebView?.settings?.userAgentString = if (next) DESKTOP_USER_AGENT else MOBILE_USER_AGENT
            addConsoleLog(ConsoleLogLevel.INFO, "تم تحويل المتصفح إلى ${if (next) "وضع الكمبيوتر" else "وضع الجوال"}")
            sharedWebView?.reload()
        }
    }

    fun clearCacheAndCookies() {
        mainHandler.post {
            try {
                sharedWebView?.clearCache(true)
                sharedWebView?.clearFormData()
                sharedWebView?.clearHistory()
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                addConsoleLog(ConsoleLogLevel.INFO, "تم مسح الكاش وملفات تعريف الارتباط بالكامل.")
                sharedWebView?.loadUrl(DEEPSEEK_CHAT_URL)
            } catch (e: Exception) {
                addConsoleLog(ConsoleLogLevel.ERROR, "خطأ أثناء مسح الكاش: ${e.message}")
            }
        }
    }

    fun autofillCredentials(emailVal: String, passVal: String, autoSubmit: Boolean = false) {
        mainHandler.post {
            // If string was typed reversed (e.g. moc.liamg@ -> @gmail.com), auto-heal
            val normalizedEmail = if (emailVal.endsWith("moc.liamg@", ignoreCase = true) || emailVal.endsWith("moc.oohay@", ignoreCase = true) || emailVal.endsWith("moc.kooltuo@", ignoreCase = true)) {
                emailVal.reversed()
            } else {
                emailVal
            }

            val encEmail = Base64.encodeToString(normalizedEmail.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val encPass = Base64.encodeToString(passVal.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

            val js = """
                (function() {
                    try {
                        const email = decodeURIComponent(escape(atob('$encEmail')));
                        const pass = decodeURIComponent(escape(atob('$encPass')));
                        const autoSubmit = $autoSubmit;

                        const inputs = document.querySelectorAll('input');
                        let emailField = null;
                        let passField = null;

                        inputs.forEach(input => {
                            const type = (input.getAttribute('type') || '').toLowerCase();
                            const name = (input.getAttribute('name') || '').toLowerCase();
                            const placeholder = (input.getAttribute('placeholder') || '').toLowerCase();

                            if (type === 'password') {
                                passField = input;
                            } else if (type === 'email' || type === 'tel' || name.includes('email') || name.includes('phone') || placeholder.includes('email') || placeholder.includes('phone') || placeholder.includes('بريد') || placeholder.includes('هاتف') || placeholder.includes('mobile')) {
                                emailField = input;
                            }
                        });

                        if (!emailField && inputs.length > 0) emailField = inputs[0];
                        if (!passField && inputs.length > 1) passField = inputs[1];

                        function setValue(input, val) {
                            if (!input) return false;
                            input.focus();
                            input.setAttribute('dir', 'ltr');
                            input.style.setProperty('direction', 'ltr', 'important');
                            input.style.setProperty('text-align', 'left', 'important');
                            input.style.setProperty('unicode-bidi', 'normal', 'important');

                            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
                            if (nativeSetter) {
                                nativeSetter.call(input, val);
                            } else {
                                input.value = val;
                            }
                            input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
                            input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
                            return true;
                        }

                        const emailFilled = setValue(emailField, email);
                        const passFilled = setValue(passField, pass);

                        // If autoSubmit is requested, tick agreement checkbox and click submit button
                        if (autoSubmit) {
                            setTimeout(() => {
                                const checkboxes = document.querySelectorAll('input[type="checkbox"], div[role="checkbox"], div[class*="ds-checkbox"]');
                                checkboxes.forEach(cb => {
                                    if (cb.tagName === 'INPUT') {
                                        if (!cb.checked) { cb.click(); }
                                    } else {
                                        const ariaChecked = cb.getAttribute('aria-checked');
                                        if (ariaChecked !== 'true') { cb.click(); }
                                    }
                                });

                                const buttons = document.querySelectorAll('button, div[role="button"]');
                                for (let btn of buttons) {
                                    const text = (btn.innerText || '').trim();
                                    const cls = (btn.className || '').toString();
                                    const type = (btn.getAttribute('type') || '').toLowerCase();
                                    if (type === 'submit' || text.includes('Log In') || text.includes('Sign in') || text.includes('Sign In') || text.includes('تسجيل الدخول') || cls.includes('ds-button--primary')) {
                                        btn.click();
                                        break;
                                    }
                                }
                            }, 350);
                        }

                        return 'البريد: ' + (emailFilled ? 'تم (LTR)' : 'لم يعثر') + ' | المرور: ' + (passFilled ? 'تم' : 'لم يعثر');
                    } catch(e) {
                        return 'خطأ: ' + e.message;
                    }
                })();
            """.trimIndent()

            sharedWebView?.evaluateJavascript(js) { res ->
                addConsoleLog(ConsoleLogLevel.INFO, "ملء الحقول: $res")
            }
        }
    }

    private fun injectAutomationBridge() {
        val script = """
            (function() {
                if (window.__deepSeekBridgeInjected) {
                    if (window.__extractAndSyncSession) { window.__extractAndSyncSession(); }
                    return;
                }
                window.__deepSeekBridgeInjected = true;

                window.__extractAndSyncSession = function() {
                    try {
                        let token = '';
                        const raw = localStorage.getItem('userToken');
                        if (raw) {
                            try {
                                const parsed = JSON.parse(raw);
                                token = parsed.value || parsed.token || '';
                            } catch(e) {
                                token = raw;
                            }
                        }

                        const hasInput = !!document.querySelector('textarea, div[contenteditable="true"], input[name="search"]');
                        const cookies = document.cookie || '';
                        const currentUrl = window.location.href;
                        const isLoginPage = currentUrl.includes('/sign_in') || currentUrl.includes('/login');
                        const isLoggedIn = !isLoginPage && ((token.length > 0) || hasInput);

                        if (window.AndroidBridge && window.AndroidBridge.onAuthSessionCaptured) {
                            window.AndroidBridge.onAuthSessionCaptured(isLoggedIn, hasInput, token, cookies, currentUrl);
                        }
                    } catch(e) {
                        console.error('Session sync error:', e);
                    }
                };

                function getAssistantContainers() {
                    const selectors = [
                        '.ds-markdown',
                        'div[class*="ds-markdown"]',
                        '[data-message-author-role="assistant"]',
                        '[data-role="assistant"]',
                        '[class*="assistant-message"]',
                        '[class*="bot-message"]'
                    ];
                    for (let selector of selectors) {
                        const nodes = document.querySelectorAll(selector);
                        if (nodes.length > 0) return Array.from(nodes);
                    }
                    return [];
                }

                window.__sendPromptToDeepSeek = function(encodedPrompt) {
                    try {
                        if (window.__ramGenerationRunning) {
                            if (window.AndroidBridge) window.AndroidBridge.onError('يوجد طلب RAM قيد التنفيذ حالياً');
                            return;
                        }

                        const promptText = decodeURIComponent(escape(atob(encodedPrompt)));
                        let input = document.querySelector('textarea, input[name="search"]');
                        if (!input) {
                            const editables = document.querySelectorAll('div[contenteditable="true"]');
                            if (editables.length > 0) input = editables[editables.length - 1];
                        }
                        if (!input) {
                            if (window.AndroidBridge) window.AndroidBridge.onError('لم يتم العثور على مربع إدخال النص في ديب سيك');
                            return;
                        }

                        // Capture the current last assistant text before sending. This prevents
                        // the polling loop from returning the previous answer as the new one.
                        const before = getAssistantContainers().map(function(el) {
                            return (el.innerText || '').trim();
                        });
                        const baseline = before.length ? before[before.length - 1] : '';

                        input.focus();
                        if (input.tagName && input.tagName.toLowerCase() === 'textarea') {
                            const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
                            if (setter) setter.call(input, promptText); else input.value = promptText;
                        } else if (input.tagName && input.tagName.toLowerCase() === 'input') {
                            const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
                            if (setter) setter.call(input, promptText); else input.value = promptText;
                        } else {
                            input.innerText = promptText;
                        }
                        input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
                        input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));

                        window.__ramGenerationRunning = true;
                        window.__ramGenerationBaseline = baseline;
                        if (window.AndroidBridge) window.AndroidBridge.onGenerationStarted();

                        setTimeout(function() {
                            let sendBtn = null;
                            const buttons = document.querySelectorAll('div[role="button"], button');
                            for (let b of buttons) {
                                const aria = (b.getAttribute('aria-label') || '').toLowerCase();
                                const cls = (b.className || '').toString().toLowerCase();
                                const text = (b.innerText || '').trim().toLowerCase();
                                if ((cls.includes('ds-button--primary') || cls.includes('send') ||
                                     aria.includes('send') || aria.includes('إرسال') || text === 'send') &&
                                    !cls.includes('disabled') && b.getAttribute('aria-disabled') !== 'true') {
                                    sendBtn = b;
                                    break;
                                }
                            }
                            if (sendBtn) sendBtn.click();
                            else input.dispatchEvent(new KeyboardEvent('keydown', {
                                key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true
                            }));
                            window.__waitForResponseCompletion();
                        }, 400);
                    } catch(e) {
                        window.__ramGenerationRunning = false;
                        if (window.AndroidBridge) window.AndroidBridge.onError('خطأ إرسال الرسالة: ' + e.message);
                    }
                };

                window.__waitForResponseCompletion = function() {
                    if (window.__ramResponsePoller) clearInterval(window.__ramResponsePoller);
                    let elapsed = 0;
                    let stableCount = 0;
                    let lastText = '';
                    const baseline = window.__ramGenerationBaseline || '';
                    const maxWaitSeconds = 90;

                    window.__ramResponsePoller = setInterval(function() {
                        elapsed += 0.5;
                        let stopBtn = null;
                        const buttons = document.querySelectorAll('div[role="button"], button');
                        for (let b of buttons) {
                            const aria = (b.getAttribute('aria-label') || '').toLowerCase();
                            const cls = (b.className || '').toString().toLowerCase();
                            if (aria.includes('stop') || aria.includes('إيقاف') || cls.includes('stop-button')) {
                                stopBtn = b;
                                break;
                            }
                        }

                        const containers = getAssistantContainers();
                        let currentText = '';
                        if (containers.length > 0) {
                            currentText = (containers[containers.length - 1].innerText || '').trim();
                        }
                        const isNew = currentText.length > 0 && currentText !== baseline;
                        if (isNew && currentText === lastText) stableCount++; else if (isNew) stableCount = 0;
                        lastText = currentText;

                        // Wait until text is new and stable, and DeepSeek is no longer streaming.
                        if (isNew && !stopBtn && stableCount >= 3) {
                            clearInterval(window.__ramResponsePoller);
                            window.__ramResponsePoller = null;
                            window.__ramGenerationRunning = false;
                            if (window.AndroidBridge) window.AndroidBridge.onGenerationCompleted(currentText);
                            return;
                        }

                        if (elapsed >= maxWaitSeconds) {
                            clearInterval(window.__ramResponsePoller);
                            window.__ramResponsePoller = null;
                            window.__ramGenerationRunning = false;
                            if (window.AndroidBridge) {
                                if (isNew) window.AndroidBridge.onGenerationCompleted(currentText);
                                else window.AndroidBridge.onError('انتهت مهلة انتظار رد ديب سيك دون رد جديد');
                            }
                        }
                    }, 500);
                };

                window.__extractAndSyncSession();
                setInterval(window.__extractAndSyncSession, 4000);
            })();
        """.trimIndent()

        mainHandler.post {
            sharedWebView?.evaluateJavascript(script, null)
        }
    }

    fun syncSessionState() {
        mainHandler.post {
            val js = """
                (function() {
                    if (window.__extractAndSyncSession) {
                        window.__extractAndSyncSession();
                    }
                })();
            """.trimIndent()
            sharedWebView?.evaluateJavascript(js, null)
        }
    }

    fun manualConfirmLogin() {
        mainHandler.post {
            val u = sharedWebView?.url ?: DEEPSEEK_CHAT_URL
            _currentUrl.value = u
            val cookieManager = CookieManager.getInstance()
            val cookies = cookieManager.getCookie(u) ?: ""
            cookieManager.flush()

            val js = """
                (function() {
                    if (window.__extractAndSyncSession) {
                        window.__extractAndSyncSession();
                    } else {
                        const raw = localStorage.getItem('userToken') || '';
                        const hasInput = !!document.querySelector('textarea, div[contenteditable="true"], input[name="search"]');
                        const page = window.location.href;
                        const isLoggedIn = !page.includes('/sign_in') && !page.includes('/login') && hasInput;
                        if (window.AndroidBridge) {
                            window.AndroidBridge.onAuthSessionCaptured(isLoggedIn, hasInput, raw, document.cookie, page);
                        }
                    }
                })();
            """.trimIndent()
            sharedWebView?.evaluateJavascript(js, null)

            addConsoleLog(
                ConsoleLogLevel.INFO,
                "جاري التحقق من جلسة DeepSeek؛ لن تُعتمد الجلسة إلا بعد إثبات تسجيل الدخول وظهور مربع الرسائل."
            )
        }
    }

    suspend fun initializeRamPersonaSession(): Boolean = withContext(Dispatchers.IO) {
        _bridgeState.value = WebBridgeState.INJECTING_RAM_PERSONA
        log("إرسال وثيقة رام v4.0 وبدء جلسة جديدة على ديب سيك...")

        val personaText = loadPersonaFromAssets()
        if (personaText.isBlank()) {
            log("خطأ: تعذر قراءة وثيقة رام من الأصول.")
            _bridgeState.value = WebBridgeState.ERROR
            return@withContext false
        }

        val handshakePrompt = """
$personaText

════════════════════════════════════════════════════════════════════
فحص الجلسة والتهيئة (Session Handshake):
أنتِ الآن ملزمة بالكامل بوثيقة رام v4.0 وبروتوكول P5 للإخراج الصارم.
أثبتي جاهزيتك فوراً بالرد بكائن JSON واحد صالح فقط دون أي نص قبله أو بعده:
{
  "thinking": "تم استلام وقراءة وثيقة رام v4.0 بالكامل. جاهزة للعمل كمستشارة شخصية.",
  "sarcasm_level": 1,
  "user_state": "جديد",
  "relationship_stage": 1,
  "messages": [
    {
      "text": "جاهزة. وثيقة رام v4.0 مفعلة، وبروتوكول P5 شغال. شو خطتك لليوم؟",
      "delay_ms": 600
    }
  ],
  "quotes": [],
  "actions": [],
  "memory_writes": [],
  "confidence": 1.0,
  "followups": []
}
        """.trimIndent()

        val response = sendRawPromptToWeb(handshakePrompt, timeoutMs = 120000L)

        _bridgeState.value = WebBridgeState.VALIDATING_FORMAT
        val isCompliant = validateStrictJson(response)

        if (isCompliant) {
            _bridgeState.value = WebBridgeState.SESSION_VERIFIED
            log("نجاح المصادقة: ديب سيك رد بصيغة JSON واعتمد شخصية رام.")
            return@withContext true
        } else {
            _bridgeState.value = WebBridgeState.FORMAT_ERROR_RETRYING
            log("تنبيه: الرد الأولي غير متوافق مع P5. إرسال تصحيح...")
            val corrected = sendRawPromptToWeb("خطأ في التنسيق: المطلوب JSON صالح فقط وفق المخطط المطلوب بلا أي نص قبله أو بعده.", 60000L)
            val recheck = validateStrictJson(corrected)
            if (recheck) {
                _bridgeState.value = WebBridgeState.SESSION_VERIFIED
                log("نجاح بعد التصحيح: اعتمد ديب سيك تنسيق JSON.")
                return@withContext true
            } else {
                _bridgeState.value = WebBridgeState.ERROR
                log("فشل: ديب سيك لم يستجب لتنسيق JSON.")
                return@withContext false
            }
        }
    }

    suspend fun executeRamTurn(
        systemPrompt: String,
        contextPrompt: String,
        recentHistory: List<Pair<String, String>> = emptyList()
    ): RamResponse = withContext(Dispatchers.IO) {
        val historyBlock = recentHistory.takeLast(6).joinToString("\n") { (sender, text) ->
            "${if (sender == "USER") "USER" else "RAM"}: $text"
        }
        val fullPrompt = buildString {
            append(systemPrompt)
            if (historyBlock.isNotBlank()) {
                append("\n\n[CONVERSATION_HISTORY]\n")
                append(historyBlock)
                append("\n[/CONVERSATION_HISTORY]")
            }
            append("\n\n")
            append(contextPrompt)
        }

        _bridgeState.value = WebBridgeState.SENDING_PROMPT
        log("إرسال الرسالة إلى ديب سيك ويب بالخلفية...")

        var rawResponse = sendRawPromptToWeb(fullPrompt, timeoutMs = 120000L)

        _bridgeState.value = WebBridgeState.VALIDATING_FORMAT
        var isValid = validateStrictJson(rawResponse)

        if (!isValid && rawResponse.isNotBlank()) {
            _bridgeState.value = WebBridgeState.FORMAT_ERROR_RETRYING
            log("تنبيه: خطأ في تنسيق JSON. إرسال تصحيح فوري...")

            val correctivePrompt = """
خطأ في التنسيق: ردك خالف بروتوكول P5. ممنوع كتابة نصوص عادية أو markdown.
أخرجي حصراً كائن JSON واحد صالح يبدأ بـ { وينتهي بـ }:
            """.trimIndent()

            rawResponse = sendRawPromptToWeb(correctivePrompt, timeoutMs = 60000L)
            isValid = validateStrictJson(rawResponse)
        }

        _lastRawOutput.value = rawResponse
        _bridgeState.value = if (isValid) WebBridgeState.LOGGED_IN_IDLE else WebBridgeState.ERROR

        if (rawResponse.isBlank()) {
            return@withContext RamResponse(
                thinking = "فشل الاتصال بديب سيك عبر المتصفح (لم يتم العثور على رد أو انتهت المهلة).",
                messages = listOf(
                    RamMessage(
                        text = "⚠️ لم أتمكن من استلام رد من ديب سيك. يرجى فتح المتصفح من الإعدادات والتأكد من تسجيل الدخول ثم الضغط على 'اعتماد'.",
                        delayMs = 500L
                    )
                ),
                confidence = 0.0
            )
        }

        RamResponseParser.parse(rawResponse)
    }

    private suspend fun sendRawPromptToWeb(prompt: String, timeoutMs: Long): String {
        return withTimeoutOrNull(timeoutMs) {
            val deferred = CompletableDeferred<String>()
            activeResponseDeferred = deferred

            val encodedPrompt = Base64.encodeToString(prompt.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

            mainHandler.post {
                val js = """
                    (function() {
                        if (window.__sendPromptToDeepSeek) {
                            window.__sendPromptToDeepSeek('$encodedPrompt');
                        } else {
                            if (window.AndroidBridge) window.AndroidBridge.onError('محرك الأتمتة غير مهيأ بعد على هذه الصفحة');
                        }
                    })();
                """.trimIndent()
                sharedWebView?.evaluateJavascript(js, null)
            }

            deferred.await()
        } ?: run {
            activeResponseDeferred = null
            ""
        }
    }

    private fun validateStrictJson(response: String): Boolean {
        if (response.isBlank()) return false
        val trimmed = response.trim()
        if (!trimmed.startsWith("{") || !trimmed.endsWith("}")) return false
        return try {
            JSONObject(trimmed)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun loadPersonaFromAssets(): String {
        return try {
            context.assets.open("ram_persona_v4.txt").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading ram_persona_v4.txt from assets", e)
            ""
        }
    }

    private fun log(message: String) {
        _lastLog.value = message
        Log.i(TAG, message)
        addConsoleLog(ConsoleLogLevel.INFO, message)
    }

    inner class JsInterface {
        @JavascriptInterface
        fun onAuthSessionCaptured(
            isLoggedIn: Boolean,
            hasInput: Boolean,
            token: String,
            cookies: String,
            url: String
        ) {
            _hasInputField.value = hasInput
            _currentUrl.value = url

            if (isLoggedIn) {
                val effectiveCookies = cookies.ifBlank { "session_captured_from_webview" }
                preferencesRepository.setCloudSession(effectiveCookies, token)
                if (_bridgeState.value == WebBridgeState.LOADING_PAGE || _bridgeState.value == WebBridgeState.REQUIRES_LOGIN || _bridgeState.value == WebBridgeState.NOT_INITIALIZED) {
                    _bridgeState.value = WebBridgeState.LOGGED_IN_IDLE
                    addConsoleLog(ConsoleLogLevel.INFO, "تم ربط الجلسة بنجاح! التوكن: ${if (token.isNotBlank()) "نشط (${token.take(8)}...)" else "عبر الجلسة"}")
                }
            } else {
                if (url.contains("/sign_in") || url.contains("/login")) {
                    preferencesRepository.clearCloudSession()
                    _bridgeState.value = WebBridgeState.REQUIRES_LOGIN
                }
            }
        }

        @JavascriptInterface
        fun onGenerationStarted() {
            _bridgeState.value = WebBridgeState.RECEIVING_RESPONSE
            addConsoleLog(ConsoleLogLevel.INFO, "ديب سيك بدأ توليد الإجابة...")
        }

        @JavascriptInterface
        fun onGenerationCompleted(text: String) {
            addConsoleLog(ConsoleLogLevel.INFO, "اكتمل استلام الرد من ديب سيك (${text.length} حرف)")
            activeResponseDeferred?.complete(text)
            activeResponseDeferred = null
        }

        @JavascriptInterface
        fun onError(msg: String) {
            addConsoleLog(ConsoleLogLevel.ERROR, "خطأ من المتصفح: $msg")
            activeResponseDeferred?.complete("")
            activeResponseDeferred = null
        }

        @JavascriptInterface
        fun onLog(msg: String) {
            addConsoleLog(ConsoleLogLevel.LOG, msg)
        }

        @JavascriptInterface
        fun onDevToolsLog(levelStr: String, text: String, source: String, line: Int) {
            val lvl = when (levelStr.uppercase()) {
                "ERROR" -> ConsoleLogLevel.ERROR
                "WARNING" -> ConsoleLogLevel.WARNING
                "DOM_PROTECT" -> ConsoleLogLevel.DOM_PROTECT
                "INFO" -> ConsoleLogLevel.INFO
                "DEBUG" -> ConsoleLogLevel.DEBUG
                else -> ConsoleLogLevel.LOG
            }
            addConsoleLog(lvl, text, source, line)
        }

        @JavascriptInterface
        fun onUserWebMessage(text: String) {
            addConsoleLog(ConsoleLogLevel.INFO, "رسالة واردة من عميل الويب المدمج: $text")
            scope.launch {
                val handler = onExternalUserPromptHandler
                if (handler != null) {
                    val response = handler(text)
                    val thinkingText = response.thinking.replace("\"", "\\\"").replace("\n", "\\n")
                    val answerText = response.messages.joinToString("\n") { it.text }.replace("\"", "\\\"").replace("\n", "\\n")
                    mainHandler.post {
                        sharedWebView?.evaluateJavascript("window.receiveAssistantTurn && window.receiveAssistantTurn(\"$thinkingText\", \"$answerText\");", null)
                    }
                }
            }
        }
    }
}
