package com.example.domain.engine

import com.example.data.model.RamAction
import com.example.data.model.RamFollowup
import com.example.data.model.RamMemoryWrite
import com.example.data.model.RamMessage
import com.example.data.model.RamQuote
import com.example.data.model.RamResponse
import org.json.JSONArray
import org.json.JSONObject

object RamResponseParser {

    fun parse(rawOutput: String): RamResponse {
        val cleaned = extractJson(rawOutput)
        if (cleaned.isBlank()) {
            return fallbackPlainResponse(rawOutput)
        }

        return try {
            val json = JSONObject(cleaned)

            val thinking = json.optString("thinking", "")
            val sarcasmLevel = json.optInt("sarcasm_level", 0)
            val userState = json.optString("user_state", "")
            val relationshipStage = json.optInt("relationship_stage", 1)
            val confidence = json.optDouble("confidence", 1.0)

            // Messages
            val messagesList = mutableListOf<RamMessage>()
            val messagesArray = json.optJSONArray("messages")
            if (messagesArray != null) {
                for (i in 0 until messagesArray.length()) {
                    val item = messagesArray.opt(i)
                    if (item is JSONObject) {
                        val text = item.optString("text", "")
                        val delay = item.optLong("delay_ms", 700L)
                        if (text.isNotBlank()) {
                            messagesList.add(RamMessage(text = text, delayMs = delay))
                        }
                    } else if (item is String && item.isNotBlank()) {
                        messagesList.add(RamMessage(text = item, delayMs = 700L))
                    }
                }
            }

            // Quotes
            val quotesList = mutableListOf<RamQuote>()
            val quotesArray = json.optJSONArray("quotes")
            if (quotesArray != null) {
                for (i in 0 until quotesArray.length()) {
                    val qObj = quotesArray.optJSONObject(i)
                    if (qObj != null) {
                        val text = qObj.optString("text", "")
                        val afterIdx = qObj.optInt("after_message_index", 0)
                        val delay = qObj.optLong("delay_ms", 900L)
                        if (text.isNotBlank()) {
                            quotesList.add(RamQuote(text, afterIdx, delay))
                        }
                    }
                }
            }

            // Actions
            val actionsList = mutableListOf<RamAction>()
            val actionsArray = json.optJSONArray("actions")
            if (actionsArray != null) {
                for (i in 0 until actionsArray.length()) {
                    val aObj = actionsArray.optJSONObject(i)
                    if (aObj != null) {
                        val type = aObj.optString("type", "")
                        val paramsObj = aObj.optJSONObject("params")
                        val paramsMap = mutableMapOf<String, Any?>()
                        if (paramsObj != null) {
                            val keys = paramsObj.keys()
                            while (keys.hasNext()) {
                                val key = keys.next()
                                paramsMap[key] = paramsObj.get(key)
                            }
                        }
                        val confirm = aObj.optBoolean("requires_confirmation", false)
                        val confirmPromptIdx = if (aObj.has("confirmation_prompt_index") && !aObj.isNull("confirmation_prompt_index")) {
                            aObj.optInt("confirmation_prompt_index")
                        } else null

                        if (type.isNotBlank()) {
                            actionsList.add(RamAction(type, paramsMap, confirm, confirmPromptIdx))
                        }
                    }
                }
            }

            // Memory Writes
            val memoryList = mutableListOf<RamMemoryWrite>()
            val memoryArray = json.optJSONArray("memory_writes")
            if (memoryArray != null) {
                for (i in 0 until memoryArray.length()) {
                    val mObj = memoryArray.optJSONObject(i)
                    if (mObj != null) {
                        val type = mObj.optString("type", "fact")
                        val key = mObj.optString("key", "")
                        val value = mObj.optString("value", "")
                        val conf = mObj.optDouble("confidence", 0.9)
                        val source = mObj.optString("source", "inferred")
                        val date = mObj.optString("date", "")
                        if (key.isNotBlank() && value.isNotBlank()) {
                            memoryList.add(RamMemoryWrite(type, key, value, conf, source, date))
                        }
                    }
                }
            }

            // Followups
            val followupsList = mutableListOf<RamFollowup>()
            val followupsArray = json.optJSONArray("followups")
            if (followupsArray != null) {
                for (i in 0 until followupsArray.length()) {
                    val fObj = followupsArray.optJSONObject(i)
                    if (fObj != null) {
                        val kind = fObj.optString("kind", "advice_check")
                        val due = fObj.optString("due", "")
                        val note = fObj.optString("note", "")
                        followupsList.add(RamFollowup(kind, due, note))
                    }
                }
            }

            if (messagesList.isEmpty()) {
                // If JSON had no messages array but maybe had a single "text" or "message"
                val fallbackText = json.optString("text", json.optString("message", ""))
                if (fallbackText.isNotBlank()) {
                    messagesList.add(RamMessage(text = fallbackText, delayMs = 700L))
                }
            }

            RamResponse(
                thinking = thinking,
                sarcasmLevel = sarcasmLevel,
                userState = userState,
                relationshipStage = relationshipStage,
                messages = messagesList.ifEmpty { listOf(RamMessage("مم.", 600L)) },
                quotes = quotesList,
                actions = actionsList,
                memoryWrites = memoryList,
                confidence = confidence,
                followups = followupsList
            )
        } catch (e: Exception) {
            fallbackPlainResponse(rawOutput)
        }
    }

    private fun extractJson(raw: String): String {
        var str = raw.trim()
        // Remove markdown backticks ```json ... ```
        if (str.startsWith("```")) {
            val firstLineBreak = str.indexOf('\n')
            if (firstLineBreak != -1) {
                str = str.substring(firstLineBreak + 1)
            }
            if (str.endsWith("```")) {
                str = str.substring(0, str.length - 3)
            }
        }
        str = str.trim()

        val firstBrace = str.indexOf('{')
        val lastBrace = str.lastIndexOf('}')
        if (firstBrace != -1 && lastBrace != -1 && lastBrace > firstBrace) {
            return str.substring(firstBrace, lastBrace + 1)
        }
        return ""
    }

    private fun fallbackPlainResponse(raw: String): RamResponse {
        val lines = raw.trim().split("\n\n").filter { it.isNotBlank() }
        val messages = if (lines.isNotEmpty()) {
            lines.map { RamMessage(text = it.trim(), delayMs = 800L) }
        } else {
            listOf(RamMessage(text = raw.ifBlank { "تنبيه: لم يتم استلام محتوى صالح." }, delayMs = 600L))
        }

        return RamResponse(
            thinking = "استجابة مباشرة دون صياغة JSON.",
            sarcasmLevel = 0,
            userState = "عادي",
            relationshipStage = 1,
            messages = messages,
            confidence = 0.9
        )
    }
}
