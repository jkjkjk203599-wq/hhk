package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskCode: String = "", // e.g. "t1"
    val title: String,
    val due: String = "", // e.g. "2026-09-30 18:00"
    val status: String = "لم تبدأ", // "لم تبدأ", "قيد التنفيذ", "منجزة", "متأخرة"
    val priority: String = "متوسطة", // "منخفضة", "متوسطة", "عالية"
    val estimatedDuration: String = "30د",
    val postponesCount: Int = 0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
