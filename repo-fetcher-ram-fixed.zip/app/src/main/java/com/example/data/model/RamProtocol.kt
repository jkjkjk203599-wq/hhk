package com.example.data.model

data class RamResponse(
    val thinking: String = "",
    val sarcasmLevel: Int = 0,
    val userState: String = "",
    val relationshipStage: Int = 0,
    val messages: List<RamMessage> = emptyList(),
    val quotes: List<RamQuote> = emptyList(),
    val actions: List<RamAction> = emptyList(),
    val memoryWrites: List<RamMemoryWrite> = emptyList(),
    val confidence: Double = 1.0,
    val followups: List<RamFollowup> = emptyList()
)

data class RamMessage(
    val text: String,
    val delayMs: Long = 800L
)

data class RamQuote(
    val text: String,
    val afterMessageIndex: Int = 0,
    val delayMs: Long = 900L
)

data class RamAction(
    val type: String,
    val params: Map<String, Any?> = emptyMap(),
    val requiresConfirmation: Boolean = false,
    val confirmationPromptIndex: Int? = null
)

data class RamMemoryWrite(
    val type: String,
    val key: String,
    val value: String,
    val confidence: Double = 0.9,
    val source: String = "inferred",
    val date: String = ""
)

data class RamFollowup(
    val kind: String = "advice_check",
    val due: String = "",
    val note: String = ""
)
