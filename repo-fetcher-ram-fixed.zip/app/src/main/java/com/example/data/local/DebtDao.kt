package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DebtEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtDao {
    @Query("SELECT * FROM debts ORDER BY createdAt DESC")
    fun getAllDebtsFlow(): Flow<List<DebtEntity>>

    @Query("SELECT * FROM debts ORDER BY createdAt DESC")
    suspend fun getAllDebts(): List<DebtEntity>

    @Query("SELECT * FROM debts WHERE id = :id OR debtCode = :code LIMIT 1")
    suspend fun getDebtByIdOrCode(id: Long, code: String): DebtEntity?

    @Query("SELECT * FROM debts WHERE party LIKE '%' || :party || '%' LIMIT 1")
    suspend fun getDebtByParty(party: String): DebtEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: DebtEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebts(debts: List<DebtEntity>): List<Long>

    @Update
    suspend fun updateDebt(debt: DebtEntity)

    @Delete
    suspend fun deleteDebt(debt: DebtEntity)

    @Query("DELETE FROM debts WHERE id = :id OR debtCode = :code")
    suspend fun deleteDebtByIdOrCode(id: Long, code: String)

    @Query("SELECT COUNT(*) FROM debts")
    suspend fun getCount(): Int
}
