package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "debts")
data class DebtEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val debtCode: String = "", // e.g. "d1"
    val party: String, // person or shop
    val direction: String = "لي", // "لي" (owed to me) or "عليّ" (I owe)
    val amount: Double = 0.0,
    val currency: String = "USD",
    val paidAmount: Double = 0.0,
    val debtDate: String = "",
    val dueDate: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val remainingAmount: Double
        get() = (amount - paidAmount).coerceAtLeast(0.0)
    
    val isFullyPaid: Boolean
        get() = paidAmount >= amount && amount > 0
}
