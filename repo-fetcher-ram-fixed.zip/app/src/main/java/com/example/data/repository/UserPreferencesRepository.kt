package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserPreferencesRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ram_user_prefs", Context.MODE_PRIVATE)

    private val _userName = MutableStateFlow(prefs.getString("user_name", "سامر") ?: "سامر")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _userGender = MutableStateFlow(prefs.getString("user_gender", "مذكر") ?: "مذكر")
    val userGender: StateFlow<String> = _userGender.asStateFlow()

    private val _isCloudConnected = MutableStateFlow(prefs.getBoolean("is_cloud_connected", false))
    val isCloudConnected: StateFlow<Boolean> = _isCloudConnected.asStateFlow()

    private val _cloudSessionCookies = MutableStateFlow(prefs.getString("cloud_cookies", "") ?: "")
    val cloudSessionCookies: StateFlow<String> = _cloudSessionCookies.asStateFlow()

    private val _cloudAuthToken = MutableStateFlow(prefs.getString("cloud_token", "") ?: "")
    val cloudAuthToken: StateFlow<String> = _cloudAuthToken.asStateFlow()

    private val _apiKey = MutableStateFlow(prefs.getString("api_key", "") ?: "")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _sarcasmTolerance = MutableStateFlow(prefs.getInt("sarcasm_tolerance", 2))
    val sarcasmTolerance: StateFlow<Int> = _sarcasmTolerance.asStateFlow()

    fun setUserName(name: String) {
        val trimmed = name.trim().ifEmpty { "سامر" }
        prefs.edit().putString("user_name", trimmed).apply()
        _userName.value = trimmed
    }

    fun setUserGender(gender: String) {
        val g = if (gender == "مؤنث") "مؤنث" else "مذكر"
        prefs.edit().putString("user_gender", g).apply()
        _userGender.value = g
    }

    fun setCloudSession(cookies: String, token: String = "") {
        prefs.edit()
            .putBoolean("is_cloud_connected", true)
            .putString("cloud_cookies", cookies)
            .putString("cloud_token", token)
            .apply()
        _isCloudConnected.value = true
        _cloudSessionCookies.value = cookies
        _cloudAuthToken.value = token
    }

    fun clearCloudSession() {
        prefs.edit()
            .putBoolean("is_cloud_connected", false)
            .putString("cloud_cookies", "")
            .putString("cloud_token", "")
            .apply()
        _isCloudConnected.value = false
        _cloudSessionCookies.value = ""
        _cloudAuthToken.value = ""
    }

    fun setApiKey(key: String) {
        val trimmed = key.trim()
        prefs.edit().putString("api_key", trimmed).apply()
        _apiKey.value = trimmed
    }

    fun setSarcasmTolerance(level: Int) {
        val lvl = level.coerceIn(0, 3)
        prefs.edit().putInt("sarcasm_tolerance", lvl).apply()
        _sarcasmTolerance.value = lvl
    }
}
