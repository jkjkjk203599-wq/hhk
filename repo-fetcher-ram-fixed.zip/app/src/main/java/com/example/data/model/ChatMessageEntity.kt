package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MessageSender {
    USER,
    RAM,
    SYSTEM
}

enum class MessageStatus {
    SENDING,
    SENT,
    DELIVERED,
    READ
}

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val replyToId: Long? = null,
    val replyToText: String? = null,
    val replyToSender: MessageSender? = null,
    val status: MessageStatus = MessageStatus.READ,
    val isStreaming: Boolean = false,
    val thinking: String? = null,
    val sarcasmLevel: Int? = null,
    val userState: String? = null,
    val pendingActionJson: String? = null,
    val quoteText: String? = null,
    val rawJson: String? = null
)
