package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sessionCode: String, // e.g. "sess_1"
    val title: String = "محادثة جديدة مع رام",
    val createdAt: Long = System.currentTimeMillis(),
    val isRamPersonaInjected: Boolean = false,
    val isFormatVerified: Boolean = false,
    val lastTestResult: String = "لم يتم الاختبار بعد",
    val isActive: Boolean = true
)
