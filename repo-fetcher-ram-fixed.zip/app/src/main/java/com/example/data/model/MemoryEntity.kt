package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey
    val key: String, // e.g. "work_type", "sarcasm_tolerance"
    val type: String = "fact", // fact | preference | goal | advice_given | advice_outcome | relationship | correction
    val value: String,
    val confidence: Double = 0.9,
    val source: String = "inferred",
    val date: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
