package com.example.data.repository

import com.example.data.local.RamDatabase
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatSessionEntity
import com.example.data.model.DebtEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.PlanEntity
import com.example.data.model.TaskEntity
import kotlinx.coroutines.flow.Flow

class RamRepository(private val database: RamDatabase) {

    // Sessions
    val sessionsFlow: Flow<List<ChatSessionEntity>> =
        database.chatSessionDao().getAllSessionsFlow()

    suspend fun getActiveSession(): ChatSessionEntity? =
        database.chatSessionDao().getActiveSession()

    suspend fun createNewSession(title: String = "جلسة جديدة مع رام"): Long {
        database.chatSessionDao().deactivateAllSessions()
        val sessionCode = "sess_${System.currentTimeMillis()}"
        return database.chatSessionDao().insertSession(
            ChatSessionEntity(
                sessionCode = sessionCode,
                title = title,
                isRamPersonaInjected = false,
                isFormatVerified = false,
                lastTestResult = "بانتظار التهيئة",
                isActive = true
            )
        )
    }

    suspend fun updateSession(session: ChatSessionEntity) =
        database.chatSessionDao().updateSession(session)

    suspend fun activateSession(id: Long) {
        database.chatSessionDao().deactivateAllSessions()
        database.chatSessionDao().activateSession(id)
    }

    // Chat
    val chatMessagesFlow: Flow<List<ChatMessageEntity>> =
        database.chatDao().getAllMessagesFlow()

    suspend fun getRecentMessages(limit: Int = 20): List<ChatMessageEntity> =
        database.chatDao().getRecentMessages(limit).asReversed()

    suspend fun insertChatMessage(message: ChatMessageEntity): Long =
        database.chatDao().insertMessage(message)

    suspend fun updateChatMessage(message: ChatMessageEntity) =
        database.chatDao().updateMessage(message)

    suspend fun deleteChatMessage(id: Long) =
        database.chatDao().deleteMessage(id)

    suspend fun clearChat() =
        database.chatDao().clearAll()

    // Tasks
    val tasksFlow: Flow<List<TaskEntity>> =
        database.taskDao().getAllTasksFlow()

    suspend fun getAllTasks(): List<TaskEntity> =
        database.taskDao().getAllTasks()

    suspend fun insertTask(task: TaskEntity): Long =
        database.taskDao().insertTask(task)

    suspend fun updateTask(task: TaskEntity) =
        database.taskDao().updateTask(task)

    suspend fun deleteTask(task: TaskEntity) =
        database.taskDao().deleteTask(task)

    suspend fun deleteTaskByIdOrCode(id: Long, code: String) =
        database.taskDao().deleteTaskByIdOrCode(id, code)

    suspend fun getTaskByIdOrCode(id: Long, code: String): TaskEntity? =
        database.taskDao().getTaskByIdOrCode(id, code)

    // Debts
    val debtsFlow: Flow<List<DebtEntity>> =
        database.debtDao().getAllDebtsFlow()

    suspend fun getAllDebts(): List<DebtEntity> =
        database.debtDao().getAllDebts()

    suspend fun insertDebt(debt: DebtEntity): Long =
        database.debtDao().insertDebt(debt)

    suspend fun updateDebt(debt: DebtEntity) =
        database.debtDao().updateDebt(debt)

    suspend fun deleteDebt(debt: DebtEntity) =
        database.debtDao().deleteDebt(debt)

    suspend fun getDebtByIdOrCode(id: Long, code: String): DebtEntity? =
        database.debtDao().getDebtByIdOrCode(id, code)

    suspend fun getDebtByParty(party: String): DebtEntity? =
        database.debtDao().getDebtByParty(party)

    // Memories
    val memoriesFlow: Flow<List<MemoryEntity>> =
        database.memoryDao().getAllMemoriesFlow()

    suspend fun getAllMemories(): List<MemoryEntity> =
        database.memoryDao().getAllMemories()

    suspend fun insertMemory(memory: MemoryEntity) =
        database.memoryDao().insertMemory(memory)

    suspend fun deleteMemoryByKey(key: String) =
        database.memoryDao().deleteMemoryByKey(key)

    // Plans
    val plansFlow: Flow<List<PlanEntity>> =
        database.planDao().getAllPlansFlow()

    suspend fun insertPlan(plan: PlanEntity): Long =
        database.planDao().insertPlan(plan)

    suspend fun updatePlan(plan: PlanEntity) =
        database.planDao().updatePlan(plan)

    suspend fun deletePlan(plan: PlanEntity) =
        database.planDao().deletePlan(plan)
}
