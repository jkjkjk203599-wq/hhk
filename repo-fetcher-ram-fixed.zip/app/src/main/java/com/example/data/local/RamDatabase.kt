package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatSessionEntity
import com.example.data.model.DebtEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.MessageSender
import com.example.data.model.MessageStatus
import com.example.data.model.PlanEntity
import com.example.data.model.TaskEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ChatMessageEntity::class,
        ChatSessionEntity::class,
        TaskEntity::class,
        DebtEntity::class,
        MemoryEntity::class,
        PlanEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class RamDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun chatSessionDao(): ChatSessionDao
    abstract fun taskDao(): TaskDao
    abstract fun debtDao(): DebtDao
    abstract fun memoryDao(): MemoryDao
    abstract fun planDao(): PlanDao

    companion object {
        @Volatile
        private var INSTANCE: RamDatabase? = null

        fun getInstance(context: Context): RamDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RamDatabase::class.java,
                    "ram_assistant_database.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    prepopulate(database)
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun prepopulate(db: RamDatabase) {
            // Initial Active Session
            val defaultSessionId = db.chatSessionDao().insertSession(
                ChatSessionEntity(
                    sessionCode = "sess_main",
                    title = "الجلسة الرئيسية مع رام",
                    isRamPersonaInjected = true,
                    isFormatVerified = true,
                    lastTestResult = "جاهزة ومتوافقة مع بروتوكول P5",
                    isActive = true
                )
            )

            // Initial Ram greeting message
            db.chatDao().insertMessage(
                ChatMessageEntity(
                    sender = MessageSender.RAM,
                    text = "أهلين. أنا رام. مستشارتك هون.\nمهامك، وقتك، ودفتر ديونك.\nوقبل ما تسأل: لا، ما رح صفّقلك عالخطط الخيالية. شو عندك اليوم؟",
                    timestamp = System.currentTimeMillis() - 60000,
                    status = MessageStatus.READ,
                    thinking = "أول محادثة. تقديم الشخصية ببرود، بلا حماس آلي، وتحديد الدور.",
                    sarcasmLevel = 1,
                    userState = "جديد"
                )
            )

            // Starter sample tasks
            db.taskDao().insertTasks(
                listOf(
                    TaskEntity(
                        taskCode = "t1",
                        title = "كتابة تقرير المشروع الأسبوعي",
                        due = "اليوم 18:00",
                        status = "لم تبدأ",
                        priority = "عالية",
                        estimatedDuration = "90د",
                        postponesCount = 1,
                        notes = "مهم جداً إرساله قبل نهاية الدوام"
                    ),
                    TaskEntity(
                        taskCode = "t2",
                        title = "الاتصال بالبنك لتأكيد الحوالة",
                        due = "غداً 10:00",
                        status = "لم تبدأ",
                        priority = "متوسطة",
                        estimatedDuration = "15د",
                        postponesCount = 0
                    )
                )
            )

            // Starter sample debts
            db.debtDao().insertDebts(
                listOf(
                    DebtEntity(
                        debtCode = "d1",
                        party = "أحمد",
                        direction = "لي",
                        amount = 250.0,
                        currency = "USD",
                        paidAmount = 50.0,
                        debtDate = "2026-08-15",
                        dueDate = "2026-09-15",
                        notes = "سلفة سابقة"
                    )
                )
            )

            // Starter memories
            db.memoryDao().insertMemories(
                listOf(
                    MemoryEntity(
                        key = "relationship_stage",
                        type = "relationship",
                        value = "1",
                        confidence = 1.0,
                        source = "app_context"
                    ),
                    MemoryEntity(
                        key = "work_style",
                        type = "preference",
                        value = "يفضّل العمل المسائي ويؤجل المهام الروتينية أحياناً",
                        confidence = 0.8,
                        source = "inferred"
                    )
                )
            )
        }
    }
}
